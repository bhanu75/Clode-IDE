# Domain and SSL Setup Guide

## Step 1: Domain Configuration

### 1.1 Purchase Domain
- Choose a domain registrar (Namecheap, GoDaddy, Cloudflare)
- Recommended domain examples:
  - `your-ide.com`
  - `cloudide-pro.dev`
  - `mydevenv.io`

### 1.2 DNS Configuration

#### For Vercel Frontend:
```
Type: CNAME
Name: @ (or www)
Value: cname.vercel-dns.com
TTL: 300
```

#### For Railway Backend:
```
Type: CNAME  
Name: api
Value: your-app.railway.app
TTL: 300
```

#### Complete DNS Setup:
```
# Main domain (Frontend)
@ → CNAME → cname.vercel-dns.com

# API subdomain (Backend)  
api → CNAME → your-backend.railway.app

# WebSocket (if separate)
ws → CNAME → your-backend.railway.app

# CDN/Assets (optional)
cdn → CNAME → your-cdn-provider.com
```

## Step 2: SSL Certificate Setup

### 2.1 Automatic SSL (Recommended)

**Vercel:**
- SSL certificates are automatically provisioned
- Supports custom domains with free SSL
- HTTPS redirect enabled by default

**Railway:**
- Automatic SSL for `.railway.app` domains
- Custom domain SSL available on Pro plan
- Let's Encrypt integration

### 2.2 Manual SSL Setup (if needed)

#### Using Cloudflare (Free SSL):
1. Add domain to Cloudflare
2. Update nameservers at registrar
3. Enable "Full (Strict)" SSL mode
4. Enable "Always Use HTTPS"
5. Set up page rules for caching

#### Using Let's Encrypt with Docker:
```bash
# For self-hosted deployments
docker run -it --rm \
  -v /etc/letsencrypt:/etc/letsencrypt \
  certbot/certbot certonly \
  --standalone \
  -d your-domain.com \
  -d api.your-domain.com
```

## Step 3: Security Headers

### 3.1 Vercel Security Headers
Add to `vercel.json`:
```json
{
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        {
          "key": "Strict-Transport-Security",
          "value": "max-age=31536000; includeSubDomains"
        },
        {
          "key": "X-Frame-Options", 
          "value": "DENY"
        },
        {
          "key": "X-Content-Type-Options",
          "value": "nosniff"
        },
        {
          "key": "Referrer-Policy",
          "value": "strict-origin-when-cross-origin"
        },
        {
          "key": "Content-Security-Policy",
          "value": "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; connect-src 'self' wss: https:;"
        }
      ]
    }
  ]
}
```

### 3.2 Backend Security Headers
```javascript
// In your Express app
app.use(helmet({
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true
  },
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      connectSrc: ["'self'", "wss:", "https:"],
      imgSrc: ["'self'", "data:", "https:"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"]
    }
  }
}));
```

## Step 4: Performance Optimization

### 4.1 CDN Configuration
```javascript
// Cloudflare settings
{
  "caching": {
    "static_assets": "1y",
    "api_responses": "0s",
    "html_pages": "1h"
  },
  "compression": {
    "gzip": true,
    "brotli": true
  },
  "minification": {
    "html": true,
    "css": true,
    "js": true
  }
}
```

### 4.2 Railway Performance
```toml
# railway.toml
[build]
builder = "NIXPACKS"

[deploy]
healthcheckPath = "/health"
healthcheckTimeout = 100
restartPolicyType = "ON_FAILURE"

[networking]
serviceDomain = "api.your-domain.com"
```

## Step 5: Monitoring & Analytics

### 5.1 Uptime Monitoring
- **UptimeRobot** (free)
- **Pingdom** 
- **StatusPage.io**

### 5.2 Error Tracking
- **Sentry** integration
- **LogRocket** for frontend
- **Winston** for backend logging

### 5.3 Analytics
- **Google Analytics**
- **Plausible** (privacy-focused)
- **Mixpanel** for events

## Step 6: Backup Strategy

### 6.1 Database Backups
```bash
# PostgreSQL backup script
#!/bin/bash
BACKUP_DIR="/backups"
DB_NAME="cloudide"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

pg_dump $DB_NAME > $BACKUP_DIR/backup_$TIMESTAMP.sql
```

### 6.2 File Storage Backup
```bash
# Workspace backup
tar -czf workspace_backup_$(date +%Y%m%d).tar.gz /workspace
aws s3 cp workspace_backup_$(date +%Y%m%d).tar.gz s3://your-backup-bucket/
```

## Step 7: Deployment Checklist

### Pre-Deployment:
- [ ] Environment variables configured
- [ ] SSL certificates ready
- [ ] DNS records updated
- [ ] Security headers implemented
- [ ] Error tracking setup
- [ ] Monitoring configured

### Post-Deployment:
- [ ] Health checks passing
- [ ] SSL working correctly
- [ ] Performance metrics baseline
- [ ] Backup systems active
- [ ] Documentation updated
- [ ] Team notified

## Step 8: Troubleshooting

### Common Issues:

**SSL Certificate Issues:**
```bash
# Check SSL certificate
openssl s_client -connect your-domain.com:443 -servername your-domain.com

# Verify certificate chain
curl -I https://your-domain.com
```

**DNS Propagation:**
```bash
# Check DNS propagation
dig your-domain.com
nslookup api.your-domain.com
```

**CORS Issues:**
```javascript
// Backend CORS configuration
app.use(cors({
  origin: [
    'https://your-domain.com',
    'https://www.your-domain.com'
  ],
  credentials: true
}));
```

**WebSocket Connection Issues:**
```javascript
// Frontend WebSocket connection
const wsUrl = location.protocol === 'https:' 
  ? 'wss://api.your-domain.com'
  : 'ws://localhost:3001';
```