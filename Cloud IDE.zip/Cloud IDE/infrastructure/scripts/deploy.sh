#!/bin/bash
# infrastructure/scripts/deploy.sh
# Cloud IDE Automated Deployment Script

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PROJECT_NAME="cloud-ide"
FRONTEND_DIR="frontend"
BACKEND_DIR="backend"
BUILD_DIR="dist"

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
    exit 1
}

check_dependencies() {
    log_info "Checking dependencies..."
    
    # Check Node.js
    if ! command -v node &> /dev/null; then
        log_error "Node.js is not installed"
    fi
    
    # Check npm
    if ! command -v npm &> /dev/null; then
        log_error "npm is not installed"
    fi
    
    # Check git
    if ! command -v git &> /dev/null; then
        log_error "git is not installed"
    fi
    
    # Check if we're in the right directory
    if [ ! -f "package.json" ]; then
        log_error "Not in project root directory"
    fi
    
    log_success "All dependencies are available"
}

build_frontend() {
    log_info "Building frontend..."
    
    cd $FRONTEND_DIR
    
    # Install dependencies
    log_info "Installing frontend dependencies..."
    npm ci
    
    # Run linting
    log_info "Running ESLint..."
    npm run lint || log_warning "Linting warnings found"
    
    # Build for production
    log_info "Building for production..."
    npm run build
    
    # Verify build
    if [ ! -d "$BUILD_DIR" ]; then
        log_error "Frontend build failed - no dist directory"
    fi
    
    cd ..
    log_success "Frontend built successfully"
}

prepare_backend() {
    log_info "Preparing backend..."
    
    cd $BACKEND_DIR
    
    # Install dependencies
    log_info "Installing backend dependencies..."
    npm ci --only=production
    
    # Run tests if available
    if npm run test --silent 2>/dev/null; then
        log_info "Running backend tests..."
        npm test
    fi
    
    cd ..
    log_success "Backend prepared successfully"
}

deploy_to_vercel() {
    log_info "Deploying frontend to Vercel..."
    
    cd $FRONTEND_DIR
    
    # Check if Vercel CLI is installed
    if ! command -v vercel &> /dev/null; then
        log_info "Installing Vercel CLI..."
        npm install -g vercel
    fi
    
    # Deploy to Vercel
    if [ "$1" = "production" ]; then
        log_info "Deploying to production..."
        vercel --prod --confirm
    else
        log_info "Deploying to preview..."
        vercel
    fi
    
    cd ..
    log_success "Frontend deployed to Vercel"
}

deploy_backend_railway() {
    log_info "Deploying backend to Railway..."
    
    cd $BACKEND_DIR
    
    # Check if Railway CLI is installed
    if ! command -v railway &> /dev/null; then
        log_info "Installing Railway CLI..."
        npm install -g @railway/cli
    fi
    
    # Deploy to Railway
    log_info "Deploying to Railway..."
    railway up
    
    cd ..
    log_success "Backend deployed to Railway"
}

deploy_with_docker() {
    log_info "Deploying with Docker..."
    
    # Build and push images
    log_info "Building Docker images..."
    
    # Build backend image
    docker build -f infrastructure/docker/backend.Dockerfile -t $PROJECT_NAME-backend:latest ./backend
    
    # Build dev container image
    docker build -f dev-container/Dockerfile -t $PROJECT_NAME-dev:latest ./dev-container
    
    # Tag and push to registry (if configured)
    if [ ! -z "$DOCKER_REGISTRY" ]; then
        log_info "Pushing to Docker registry..."
        docker tag $PROJECT_NAME-backend:latest $DOCKER_REGISTRY/$PROJECT_NAME-backend:latest
        docker tag $PROJECT_NAME-dev:latest $DOCKER_REGISTRY/$PROJECT_NAME-dev:latest
        
        docker push $DOCKER_REGISTRY/$PROJECT_NAME-backend:latest
        docker push $DOCKER_REGISTRY/$PROJECT_NAME-dev:latest
    fi
    
    log_success "Docker images built and pushed"
}

setup_environment() {
    log_info "Setting up environment..."
    
    # Create production environment files if they don't exist
    if [ ! -f "$FRONTEND_DIR/.env.production" ]; then
        log_warning "No production environment file found for frontend"
        log_info "Creating from template..."
        cp "$FRONTEND_DIR/.env.example" "$FRONTEND_DIR/.env.production"
        log_warning "Please update $FRONTEND_DIR/.env.production with production values"
    fi
    
    if [ ! -f "$BACKEND_DIR/.env" ]; then
        log_warning "No environment file found for backend"
        log_info "Creating from template..."
        cp "$BACKEND_DIR/.env.example" "$BACKEND_DIR/.env"
        log_warning "Please update $BACKEND_DIR/.env with production values"
    fi
    
    log_success "Environment setup complete"
}

run_health_checks() {
    log_info "Running health checks..."
    
    # Check if backend is accessible (if URL is provided)
    if [ ! -z "$BACKEND_URL" ]; then
        log_info "Checking backend health..."
        if curl -f "$BACKEND_URL/health" > /dev/null 2>&1; then
            log_success "Backend is healthy"
        else
            log_warning "Backend health check failed"
        fi
    fi
    
    # Check if frontend is accessible (if URL is provided)
    if [ ! -z "$FRONTEND_URL" ]; then
        log_info "Checking frontend..."
        if curl -f "$FRONTEND_URL" > /dev/null 2>&1; then
            log_success "Frontend is accessible"
        else
            log_warning "Frontend accessibility check failed"
        fi
    fi
}

show_help() {
    cat << EOF
Cloud IDE Deployment Script

Usage: $0 [COMMAND] [OPTIONS]

Commands:
    frontend        Deploy frontend only
    backend         Deploy backend only
    full            Deploy both frontend and backend
    docker          Build and deploy Docker images
    health          Run health checks
    
Options:
    --production    Deploy to production (default: preview)
    --skip-build    Skip build step
    --skip-tests    Skip running tests
    --help          Show this help message

Environment Variables:
    FRONTEND_URL    Frontend URL for health checks
    BACKEND_URL     Backend URL for health checks
    DOCKER_REGISTRY Docker registry for pushing images
    
Examples:
    $0 full --production
    $0 frontend
    $0 backend --skip-tests
    $0 docker

EOF
}

# Main execution
main() {
    local command=${1:-"help"}
    local environment="preview"
    local skip_build=false
    local skip_tests=false
    
    # Parse arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            --production)
                environment="production"
                shift
                ;;
            --skip-build)
                skip_build=true
                shift
                ;;
            --skip-tests)
                skip_tests=true
                shift
                ;;
            --help)
                show_help
                exit 0
                ;;
            *)
                command=$1
                shift
                ;;
        esac
    done
    
    echo -e "${BLUE}"
    echo "╔═══════════════════════════════════════╗"
    echo "║           Cloud IDE Deployment       ║"
    echo "║                                       ║"
    echo "║  🚀 Deploying to $environment environment  ║"
    echo "╚═══════════════════════════════════════╝"
    echo -e "${NC}"
    
    # Check dependencies
    check_dependencies
    
    # Setup environment
    setup_environment
    
    case $command in
        frontend)
            if [ "$skip_build" = false ]; then
                build_frontend
            fi
            deploy_to_vercel $environment
            ;;
        backend)
            if [ "$skip_build" = false ]; then
                prepare_backend
            fi
            deploy_backend_railway
            ;;
        full)
            if [ "$skip_build" = false ]; then
                build_frontend
                prepare_backend
            fi
            deploy_to_vercel $environment
            deploy_backend_railway
            ;;
        docker)
            if [ "$skip_build" = false ]; then
                prepare_backend
            fi
            deploy_with_docker
            ;;
        health)
            run_health_checks
            ;;
        help)
            show_help
            ;;
        *)
            log_error "Unknown command: $command"
            show_help
            exit 1
            ;;
    esac
    
    log_success "Deployment completed successfully! 🎉"
    
    if [ "$environment" = "production" ]; then
        echo ""
        echo -e "${GREEN}🎊 Production deployment complete! 🎊${NC}"
        echo ""
        echo "Frontend URL: ${FRONTEND_URL:-'Check Vercel dashboard'}"
        echo "Backend URL: ${BACKEND_URL:-'Check Railway dashboard'}"
        echo ""
        echo "Next steps:"
        echo "1. Configure custom domain (if needed)"
        echo "2. Set up monitoring and alerts"
        echo "3. Configure backups"
        echo "4. Update DNS records"
    fi
}

# Run main function with all arguments
main "$@"