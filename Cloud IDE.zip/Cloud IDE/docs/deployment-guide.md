#!/bin/bash
# Quick Deployment Commands for Cloud IDE

echo "🚀 Cloud IDE - Quick Deployment Guide"
echo "======================================"

# 1. FRONTEND DEPLOYMENT (Vercel)
echo ""
echo "📱 Frontend Deployment (Vercel):"
echo "--------------------------------"
echo "1. Install Vercel CLI:"
echo "   npm install -g vercel"
echo ""
echo "2. Login to Vercel:"
echo "   vercel login"
echo ""
echo "3. Deploy frontend:"
echo "   cd frontend"
echo "   vercel --prod"
echo ""

# 2. BACKEND DEPLOYMENT (Railway)
echo "🔧 Backend Deployment (Railway):"
echo "--------------------------------"
echo "1. Install Railway CLI:"
echo "   npm install -g @railway/cli"
echo ""
echo "2. Login to Railway:"
echo "   railway login"
echo ""
echo "3. Initialize project:"
echo "   railway init"
echo ""
echo "4. Deploy backend:"
echo "   cd backend"
echo "   railway up"
echo ""

# 3. ENVIRONMENT VARIABLES
echo "⚙️ Environment Variables Setup:"
echo "------------------------------"
echo "Frontend (.env.production):"
cat << 'EOF'
VITE_API_URL=https://your-backend.railway.app
VITE_WS_URL=wss://your-backend.railway.app
VITE_APP_NAME=Cloud IDE
VITE_ENABLE_ANALYTICS=true
EOF

echo ""
echo "Backend (.env):"
cat << 'EOF'
NODE_ENV=production
PORT=3001
CORS_ORIGIN=https://your-frontend.vercel.app
JWT_SECRET=your-super-secret-key
WORKSPACE_PATH=/workspace
EOF

echo ""
echo "4. SET VERCEL ENVIRONMENT VARIABLES:"
echo "   vercel env add VITE_API_URL"
echo "   vercel env add VITE_WS_URL"
echo ""

echo "5. SET RAILWAY ENVIRONMENT VARIABLES:"
echo "   railway variables set NODE_ENV=production"
echo "   railway variables set CORS_ORIGIN=https://your-frontend.vercel.app"
echo ""

# 4. DOMAIN SETUP
echo "🌐 Domain Configuration:"
echo "-----------------------"
echo "1. Frontend (Vercel):"
echo "   - Go to Vercel Dashboard → Project → Settings → Domains"
echo "   - Add custom domain: your-domain.com"
echo "   - Configure DNS: CNAME @ → cname.vercel-dns.com"
echo ""
echo "2. Backend (Railway):"
echo "   - Go to Railway Dashboard → Project → Settings → Networking"
echo "   - Add custom domain: api.your-domain.com"
echo "   - Configure DNS: CNAME api → your-project.railway.app"
echo ""

# 5. DOCKER DEPLOYMENT (Alternative)
echo "🐳 Docker Deployment (Alternative):"
echo "-----------------------------------"
echo "1. Build images:"
echo "   docker build -f infrastructure/docker/backend.Dockerfile -t cloud-ide-backend ."
echo "   docker build -f dev-container/Dockerfile -t cloud-ide-dev ./dev-container"
echo ""
echo "2. Run with Docker Compose:"
echo "   docker-compose -f docker-compose.production.yml up -d"
echo ""

# 6. MONITORING SETUP
echo "📊 Monitoring Setup:"
echo "-------------------"
echo "1. Add Sentry for error tracking:"
echo "   npm install @sentry/node @sentry/browser"
echo ""
echo "2. Add health checks:"
echo "   curl https://api.your-domain.com/health"
echo ""
echo "3. Set up uptime monitoring:"
echo "   - UptimeRobot (free)"
echo "   - Pingdom"
echo ""

# 7. SECURITY CHECKLIST
echo "🔒 Security Checklist:"
echo "---------------------"
echo "✅ SSL certificates (auto via Vercel/Railway)"
echo "✅ Security headers configured"
echo "✅ CORS properly set"
echo "✅ Environment variables secure"
echo "✅ No sensitive data in frontend"
echo "✅ Rate limiting enabled"
echo "✅ Input validation active"
echo ""

# 8. FINAL VERIFICATION
echo "✅ Final Verification Steps:"
echo "---------------------------"
echo "1. Test frontend: https://your-domain.com"
echo "2. Test backend API: https://api.your-domain.com/health"
echo "3. Test WebSocket: Open browser dev tools → Network"
echo "4. Test file operations: Create/edit/delete files"
echo "5. Test terminal: Open terminal, run commands"
echo "6. Test project creation: Create new React project"
echo ""

echo "🎉 Deployment Complete!"
echo ""
echo "Your Cloud IDE is now live at:"
echo "Frontend: https://your-domain.com"
echo "Backend: https://api.your-domain.com" 
echo ""
echo "Next steps:"
echo "- Set up monitoring alerts"
echo "- Configure backups"
echo "- Add team members"
echo "- Custom domain SSL verification"
echo "- Performance optimization"