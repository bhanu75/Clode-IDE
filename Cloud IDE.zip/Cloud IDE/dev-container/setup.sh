#!/bin/bash
# dev-container/setup.sh - Enhanced Development Environment Setup

set -e

echo "🚀 Setting up Multi-Language Cloud IDE Development Environment..."

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Install Oh My Zsh for better terminal experience
log_info "Installing Oh My Zsh..."
if [ ! -d "$HOME/.oh-my-zsh" ]; then
    sh -c "$(curl -fsSL https://raw.github.com/ohmyzsh/ohmyzsh/master/tools/install.sh)" "" --unattended
    
    # Install useful plugins
    git clone https://github.com/zsh-users/zsh-autosuggestions ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-autosuggestions
    git clone https://github.com/zsh-users/zsh-syntax-highlighting.git ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-syntax-highlighting
    git clone https://github.com/zsh-users/zsh-completions ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-completions
    
    log_success "Oh My Zsh installed with plugins"
else
    log_info "Oh My Zsh already installed"
fi

# Configure Zsh
log_info "Configuring Zsh..."
cat > ~/.zshrc << 'EOF'
export ZSH="$HOME/.oh-my-zsh"
ZSH_THEME="robbyrussell"

plugins=(
    git
    node
    npm
    python
    pip
    docker
    golang
    rust
    zsh-autosuggestions
    zsh-syntax-highlighting
    zsh-completions
)

source $ZSH/oh-my-zsh.sh

# Environment Variables
export WORKSPACE_PATH="/workspace"
export EDITOR="vim"
export BROWSER=""
export PATH="$HOME/.local/bin:$HOME/.cargo/bin:$HOME/go/bin:$PATH"
export GOPATH="$HOME/go"
export JAVA_HOME="/usr/lib/jvm/java-17-openjdk-amd64"
export MAVEN_HOME="/opt/maven"
export GRADLE_HOME="/opt/gradle"
export PATH="$MAVEN_HOME/bin:$GRADLE_HOME/bin:/usr/local/go/bin:$PATH"

# Custom aliases for Cloud IDE
alias ll='ls -la'
alias la='ls -A'
alias l='ls -CF'
alias ..='cd ..'
alias ...='cd ../..'
alias ....='cd ../../..'

# Git aliases
alias gs='git status'
alias ga='git add'
alias gc='git commit'
alias gp='git push'
alias gl='git log --oneline'
alias gb='git branch'
alias gco='git checkout'
alias gd='git diff'
alias gpl='git pull'

# npm aliases
alias ni='npm install'
alias ns='npm start'
alias nt='npm test'
alias nb='npm run build'
alias nd='npm run dev'
alias nr='npm run'

# Python aliases
alias py='python3'
alias pip='pip3'
alias venv='python3 -m venv'
alias activate='source venv/bin/activate'

# Docker aliases
alias dc='docker-compose'
alias dcu='docker-compose up'
alias dcd='docker-compose down'
alias dcb='docker-compose build'

# Development shortcuts
alias serve='python3 -m http.server 8000'
alias pyserver='python3 -m http.server'
alias reactnew='npx create-react-app'
alias vitenew='npm create vite@latest'
alias nextnew='npx create-next-app@latest'
alias flasknew='flask --app app.py --debug run'
alias djangonew='django-admin startproject'

# Language version managers
alias nvmuse='nvm use'
alias rbenvuse='rbenv global'

# Utility functions
mkcd() { mkdir -p "$1" && cd "$1"; }
extract() {
    if [ -f $1 ] ; then
        case $1 in
            *.tar.bz2)   tar xjf $1     ;;
            *.tar.gz)    tar xzf $1     ;;
            *.bz2)       bunzip2 $1     ;;
            *.rar)       unrar e $1     ;;
            *.gz)        gunzip $1      ;;
            *.tar)       tar xf $1      ;;
            *.tbz2)      tar xjf $1     ;;
            *.tgz)       tar xzf $1     ;;
            *.zip)       unzip $1       ;;
            *.Z)         uncompress $1  ;;
            *.7z)        7z x $1        ;;
            *)     echo "'$1' cannot be extracted via extract()" ;;
        esac
    else
        echo "'$1' is not a valid file"
    fi
}

# Auto-completion
autoload -U compinit && compinit

EOF

# Install Node.js development tools globally
log_info "Installing Node.js development tools..."
npm install -g \
    create-react-app \
    create-next-app \
    @vitejs/create-vite \
    create-vue@latest \
    @angular/cli \
    typescript \
    ts-node \
    tsx \
    nodemon \
    pm2 \
    prettier \
    eslint \
    @typescript-eslint/parser \
    @typescript-eslint/eslint-plugin \
    express-generator \
    nest-cli \
    vite \
    webpack-cli \
    serve \
    http-server \
    live-server \
    json-server \
    concurrently \
    cross-env \
    dotenv-cli \
    rimraf

log_success "Node.js tools installed"

# Install Python development tools
log_info "Installing Python development tools..."
pip3 install --user \
    # Web frameworks
    django \
    flask \
    fastapi \
    uvicorn \
    gunicorn \
    # Data science
    numpy \
    pandas \
    matplotlib \
    seaborn \
    plotly \
    scipy \
    scikit-learn \
    jupyter \
    jupyterlab \
    # Development tools
    requests \
    aiohttp \
    sqlalchemy \
    alembic \
    pydantic \
    pytest \
    black \
    flake8 \
    mypy \
    bandit \
    # Utilities
    python-dotenv \
    click \
    rich \
    typer \
    httpx

log_success "Python tools installed"

# Configure Git
log_info "Configuring Git..."
git config --global init.defaultBranch main
git config --global core.editor "vim"
git config --global pull.rebase false
git config --global core.autocrlf input
git config --global user.name "Cloud IDE User"
git config --global user.email "user@cloudide.dev"

# Install Rust tools
log_info "Installing Rust development tools..."
if command_exists rustup; then
    rustup component add clippy rustfmt rust-src rust-analyzer
    cargo install \
        cargo-watch \
        cargo-edit \
        cargo-audit \
        cargo-outdated \
        serde_json \
        tokio \
        wasm-pack
    log_success "Rust tools installed"
fi

# Install Go tools
log_info "Installing Go development tools..."
if command_exists go; then
    go install golang.org/x/tools/gopls@latest
    go install github.com/air-verse/air@latest
    go install github.com/goreleaser/goreleaser@latest
    go install github.com/golangci/golangci-lint/cmd/golangci-lint@latest
    log_success "Go tools installed"
fi

# Install Java/Maven/Gradle tools
log_info "Setting up Java development environment..."
if command_exists mvn; then
    # Create Maven settings
    mkdir -p ~/.m2
    cat > ~/.m2/settings.xml << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<settings xmlns="http://maven.apache.org/SETTINGS/1.0.0"
          xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
          xsi:schemaLocation="http://maven.apache.org/SETTINGS/1.0.0 
          http://maven.apache.org/xsd/settings-1.0.0.xsd">
    <localRepository>${user.home}/.m2/repository</localRepository>
</settings>
EOF
    log_success "Maven configured"
fi

# Install PHP tools
log_info "Installing PHP development tools..."
if command_exists composer; then
    composer global require \
        phpunit/phpunit \
        squizlabs/php_codesniffer \
        friendsofphp/php-cs-fixer \
        phpstan/phpstan \
        laravel/installer \
        symfony/cli
    log_success "PHP tools installed"
fi

# Create workspace directory structure
log_info "Setting up workspace structure..."
mkdir -p $WORKSPACE_PATH/{projects,templates,shared,tools,scripts}

# Create project templates
log_info "Creating project templates..."

# React TypeScript Template
mkdir -p $WORKSPACE_PATH/templates/react-typescript
cat > $WORKSPACE_PATH/templates/react-typescript/create.sh << 'EOF'
#!/bin/bash
PROJECT_NAME=$1
cd /workspace/projects
npm create vite@latest $PROJECT_NAME -- --template react-ts
cd $PROJECT_NAME
npm install
npm install -D @types/node
echo "✅ React TypeScript project '$PROJECT_NAME' created!"
EOF

# Next.js Template
mkdir -p $WORKSPACE_PATH/templates/nextjs-full
cat > $WORKSPACE_PATH/templates/nextjs-full/create.sh << 'EOF'
#!/bin/bash
PROJECT_NAME=$1
cd /workspace/projects
npx create-next-app@latest $PROJECT_NAME --typescript --tailwind --eslint --app --src-dir --import-alias "@/*"
cd $PROJECT_NAME
npm install @next/bundle-analyzer
echo "✅ Next.js project '$PROJECT_NAME' created!"
EOF

# Python FastAPI Template
mkdir -p $WORKSPACE_PATH/templates/python-fastapi
cat > $WORKSPACE_PATH/templates/python-fastapi/create.sh << 'EOF'
#!/bin/bash
PROJECT_NAME=$1
cd /workspace/projects
mkdir $PROJECT_NAME && cd $PROJECT_NAME
python3 -m venv venv
source venv/bin/activate
pip install fastapi uvicorn python-multipart jinja2 sqlalchemy alembic
mkdir -p app/{api,core,models,schemas}
cat > app/main.py << 'PYEOF'
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="FastAPI Project", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {"message": "Hello World from FastAPI!"}

@app.get("/health")
def health_check():
    return {"status": "healthy"}
PYEOF
cat > requirements.txt << 'PYEOF'
fastapi==0.104.1
uvicorn[standard]==0.24.0
python-multipart==0.0.6
jinja2==3.1.2
sqlalchemy==2.0.23
alembic==1.12.1
PYEOF
echo "✅ Python FastAPI project '$PROJECT_NAME' created!"
echo "To run: cd $PROJECT_NAME && source venv/bin/activate && uvicorn app.main:app --reload"
EOF

# Go Web API Template
mkdir -p $WORKSPACE_PATH/templates/go-api
cat > $WORKSPACE_PATH/templates/go-api/create.sh << 'EOF'
#!/bin/bash
PROJECT_NAME=$1
cd /workspace/projects
mkdir $PROJECT_NAME && cd $PROJECT_NAME
go mod init $PROJECT_NAME
go get github.com/gin-gonic/gin
go get github.com/joho/godotenv
cat > main.go << 'GOEOF'
package main

import (
    "net/http"
    "github.com/gin-gonic/gin"
)

func main() {
    r := gin.Default()
    
    r.GET("/", func(c *gin.Context) {
        c.JSON(http.StatusOK, gin.H{
            "message": "Hello World from Go API!",
        })
    })
    
    r.GET("/health", func(c *gin.Context) {
        c.JSON(http.StatusOK, gin.H{
            "status": "healthy",
        })
    })
    
    r.Run(":8080")
}
GOEOF
echo "✅ Go API project '$PROJECT_NAME' created!"
echo "To run: cd $PROJECT_NAME && go run main.go"
EOF

# Make template scripts executable
chmod +x $WORKSPACE_PATH/templates/*/create.sh

# Create useful scripts
log_info "Creating utility scripts..."

# Project launcher script
cat > $HOME/.local/bin/create-project << 'EOF'
#!/bin/bash
# Cloud IDE Project Creator

echo "🚀 Cloud IDE Project Creator"
echo "Available templates:"
echo "1. React TypeScript (react-ts)"
echo "2. Next.js Full Stack (nextjs)"
echo "3. Python FastAPI (fastapi)"
echo "4. Go Web API (go-api)"
echo "5. Vanilla JavaScript (vanilla)"
echo "6. Node.js Express (express)"

read -p "Select template (1-6): " choice
read -p "Project name: " project_name

if [ -z "$project_name" ]; then
    echo "❌ Project name is required"
    exit 1
fi

case $choice in
    1) /workspace/templates/react-typescript/create.sh "$project_name" ;;
    2) /workspace/templates/nextjs-full/create.sh "$project_name" ;;
    3) /workspace/templates/python-fastapi/create.sh "$project_name" ;;
    4) /workspace/templates/go-api/create.sh "$project_name" ;;
    5) 
        cd /workspace/projects
        mkdir "$project_name" && cd "$project_name"
        cat > index.html << 'HTMLEOF'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Name</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>🚀 Welcome to Your Project!</h1>
        <p>Start building something amazing!</p>
    </div>
    <script src="script.js"></script>
</body>
</html>
HTMLEOF
        cat > style.css << 'CSSEOF'
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
}

.container {
    text-align: center;
    color: white;
    background: rgba(255, 255, 255, 0.1);
    padding: 2rem;
    border-radius: 10px;
    backdrop-filter: blur(10px);
}

h1 { margin-bottom: 1rem; }
CSSEOF
        cat > script.js << 'JSEOF'
console.log('🚀 Project initialized!');

document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded successfully');
});
JSEOF
        echo "✅ Vanilla JavaScript project '$project_name' created!"
        ;;
    6)
        cd /workspace/projects
        mkdir "$project_name" && cd "$project_name"
        npm init -y
        npm install express cors helmet morgan dotenv
        npm install -D nodemon
        cat > app.js << 'JSEOF'
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(helmet());
app.use(cors());
app.use(morgan('combined'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.get('/', (req, res) => {
    res.json({ message: 'Hello World from Express!' });
});

app.get('/health', (req, res) => {
    res.json({ status: 'healthy' });
});

app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
});
JSEOF
        cat > .env << 'ENVEOF'
PORT=3000
NODE_ENV=development
ENVEOF
        # Update package.json scripts
        npm pkg set scripts.start="node app.js"
        npm pkg set scripts.dev="nodemon app.js"
        echo "✅ Express.js project '$project_name' created!"
        echo "To run: cd $project_name && npm run dev"
        ;;
    *) echo "❌ Invalid choice" && exit 1 ;;
esac
EOF

chmod +x $HOME/.local/bin/create-project

# Create welcome file with comprehensive documentation
cat > $WORKSPACE_PATH/README.md << 'EOF'
# 🚀 Cloud IDE Multi-Language Development Environment

Welcome to your comprehensive development environment! This container includes everything you need for modern software development.

## 📋 Installed Languages & Frameworks

### JavaScript/TypeScript
- **Node.js 20** (LTS) with npm, yarn, pnpm
- **React, Next.js, Vue.js, Angular** project generators
- **Express.js, Nest.js** for backend development
- **TypeScript, ESLint, Prettier** for code quality

### Python 3.11
- **Django, Flask, FastAPI** web frameworks
- **NumPy, Pandas, Matplotlib** for data science
- **Jupyter Lab** for interactive development
- **Pytest, Black, Flake8** for testing and formatting

### Java 17
- **Maven & Gradle** build tools
- **Spring Boot** ready environment
- **JUnit** testing framework

### Go 1.21
- **Gin, Echo** web frameworks
- **Go modules** dependency management
- **Built-in testing** and benchmarking

### Rust (Latest Stable)
- **Cargo** package manager
- **Clippy & Rustfmt** for code quality
- **WASM support** with wasm-pack

### PHP 8.2
- **Composer** dependency manager
- **Laravel & Symfony** framework support
- **PHPUnit** testing framework

### C/C++
- **GCC & Clang** compilers
- **CMake** build system
- **GDB & Valgrind** debugging tools
- **Boost** libraries

## 🛠️ Development Tools

### Editors & IDEs
- **Vim** with enhanced configuration
- **Nano** for quick edits
- **VS Code** compatible environment

### Version Control
- **Git** with LFS support
- **GitHub CLI** for repository management

### Databases
- **PostgreSQL, MySQL** client tools
- **SQLite3** for lightweight databases
- **Redis** client tools

### Containerization
- **Docker CLI** for container management
- **Docker Compose** support

### Utilities
- **jq** for JSON processing
- **ripgrep** for fast searching
- **fd** for file finding
- **htop** for process monitoring
- **tmux/screen** for session management

## 🚀 Quick Start Commands

### Create New Projects
```bash
# Interactive project creator
create-project

# Direct commands
npm create vite@latest my-react-app -- --template react-ts
npx create-next-app@latest my-nextjs-app
django-admin startproject my-django-app
go mod init my-go-app
cargo new my-rust-app
```

### Development Servers
```bash
npm run dev          # Node.js projects
python manage.py runserver  # Django
uvicorn main:app --reload   # FastAPI
go run main.go       # Go applications
cargo run            # Rust projects
```

### Testing
```bash
npm test            # JavaScript/TypeScript
pytest              # Python
mvn test            # Java with Maven
go test ./...       # Go
cargo test          # Rust
```

### Code Formatting
```bash
prettier --write .  # JavaScript/TypeScript
black .             # Python
gofmt -w .          # Go
cargo fmt           # Rust
```

## 📁 Directory Structure

```
/workspace/
├── projects/       # Your development projects
├── templates/      # Project templates
├── shared/         # Shared resources
├── tools/          # Custom tools and scripts
└── scripts/        # Utility scripts
```

## 🎯 Environment Variables

```bash
WORKSPACE_PATH=/workspace
GOPATH=$HOME/go
JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
MAVEN_HOME=/opt/maven
GRADLE_HOME=/opt/gradle
```

## 💡 Tips & Tricks

### Terminal Enhancements
- Use `ll` for detailed file listing
- Use#!/bin/bash
# dev-container/setup.sh

echo "🚀 Setting up Cloud IDE Development Environment..."

# Update system
sudo apt-get update

# Install zsh and oh-my-zsh for better terminal experience
sudo apt-get install -y zsh
sh -c "$(curl -fsSL https://raw.github.com/ohmyzsh/ohmyzsh/master/tools/install.sh)" "" --unattended
sudo chsh -s $(which zsh) $USER

# Install useful CLI tools
sudo apt-get install -y \
    tree \
    htop \
    wget \
    curl \
    git \
    vim \
    nano \
    tmux \
    screen \
    jq \
    zip \
    unzip

# Install development tools
sudo apt-get install -y \
    build-essential \
    python3-pip \
    default-jdk \
    golang-go

# Install Node.js tools globally
npm install -g \
    create-react-app \
    create-next-app \
    @vitejs/create-vite \
    typescript \
    ts-node \
    nodemon \
    pm2 \
    prettier \
    eslint \
    @angular/cli \
    vue@next \
    express-generator \
    serve \
    http-server \
    live-server

# Install Python packages
pip3 install \
    numpy \
    pandas \
    requests \
    fastapi \
    uvicorn \
    django \
    flask \
    jupyter

# Set up Git configuration
git config --global init.defaultBranch main
git config --global core.editor "vim"

# Create useful aliases
cat >> ~/.zshrc << 'EOF'

# Custom aliases for Cloud IDE
alias ll='ls -la'
alias la='ls -A'
alias l='ls -CF'
alias ..='cd ..'
alias ...='cd ../..'
alias ....='cd ../../..'

# Git aliases
alias gs='git status'
alias ga='git add'
alias gc='git commit'
alias gp='git push'
alias gl='git log --oneline'
alias gb='git branch'
alias gco='git checkout'

# npm aliases
alias ni='npm install'
alias ns='npm start'
alias nt='npm test'
alias nb='npm run build'
alias nd='npm run dev'

# Development shortcuts
alias serve='python3 -m http.server 8000'
alias pyserver='python3 -m http.server'
alias reactnew='npx create-react-app'
alias vitenew='npm create vite@latest'
alias nextnew='npx create-next-app@latest'

EOF

# Create workspace directory structure
mkdir -p $WORKSPACE_PATH/{projects,templates,shared}

# Create welcome file
cat > $WORKSPACE_PATH/README.md << 'EOF'
# Welcome to Cloud IDE! 🚀

## Quick Start Commands

### Create New Projects
```bash
# React with Vite
npm create vite@latest my-react-app -- --template react

# Next.js
npx create-next-app@latest my-nextjs-app

# Express API
mkdir my-api && cd my-api
npm init -y
npm install express
```

### Development Commands
```bash
npm run dev          # Start development server
npm run build        # Build for production
npm test            # Run tests
npm install package  # Install new package
```

### Useful Commands
```bash
tree                # Show directory structure
htop                # Process monitor
git status          # Check git status
code .              # Open in VS Code (if available)
```

Happy coding! 🎉
EOF

# Create sample project templates
mkdir -p $WORKSPACE_PATH/templates/vanilla-starter
cat > $WORKSPACE_PATH/templates/vanilla-starter/index.html << 'EOF'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cloud IDE Starter</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>🚀 Cloud IDE Starter Template</h1>
        <p>Start building your awesome project!</p>
        <button onclick="sayHello()">Click me!</button>
    </div>
    <script src="script.js"></script>
</body>
</html>
EOF

cat > $WORKSPACE_PATH/templates/vanilla-starter/style.css << 'EOF'
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
}

.container {
    text-align: center;
    background: rgba(255, 255, 255, 0.9);
    padding: 2rem;
    border-radius: 10px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
}

h1 {
    color: #2c3e50;
    margin-bottom: 1rem;
}

button {
    background: #3498db;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    margin-top: 1rem;
    transition: background 0.3s;
}

button:hover {
    background: #2980b9;
}
EOF

cat > $WORKSPACE_PATH/templates/vanilla-starter/script.js << 'EOF'
console.log('🚀 Cloud IDE is ready!');

function sayHello() {
    alert('Hello from Cloud IDE! 🎉');
    console.log('Button clicked!');
}

// Add some interactivity
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded successfully');
    
    // Add some animations
    const container = document.querySelector('.container');
    container.style.opacity = '0';
    container.style.transform = 'translateY(20px)';
    
    setTimeout(() => {
        container.style.transition = 'all 0.5s ease';
        container.style.opacity = '1';
        container.style.transform = 'translateY(0)';
    }, 100);
});
EOF

echo "✅ Cloud IDE Development Environment setup complete!"
echo "🔄 Please restart your terminal or run: source ~/.zshrc"
echo "📁 Workspace ready at: $WORKSPACE_PATH"