// frontend/src/components/Editor.js

/**
 * Monaco Editor Component
 * Handles code editing with syntax highlighting and IntelliSense
 */
export class Editor {
    constructor(options) {
        this.container = options.container;
        this.welcomeContainer = options.welcomeContainer;
        this.tabContainer = options.tabContainer;
        this.onFileChange = options.onFileChange || (() => {});
        this.onFileSave = options.onFileSave || (() => {});
        
        this.editor = null;
        this.openTabs = new Map();
        this.activeTab = null;
        this.theme = 'vs-dark';
        this.fontSize = 14;
        this.wordWrap = 'on';
        
        this.isInitialized = false;
        this.pendingFiles = [];
    }

    async init() {
        try {
            // Load Monaco Editor
            await this.loadMonaco();
            
            // Initialize editor
            this.initializeEditor();
            
            // Set up event listeners
            this.setupEventListeners();
            
            // Show welcome screen initially
            this.showWelcome();
            
            this.isInitialized = true;
            
            // Open any pending files
            while (this.pendingFiles.length > 0) {
                const filePath = this.pendingFiles.shift();
                await this.openFile(filePath);
            }
            
        } catch (error) {
            console.error('Failed to initialize Monaco Editor:', error);
            this.showError('Failed to initialize code editor');
        }
    }

    async loadMonaco() {
        return new Promise((resolve, reject) => {
            if (window.monaco) {
                resolve();
                return;
            }

            // Monaco is loaded via script tag in HTML
            // Wait for it to be available
            const checkMonaco = () => {
                if (window.monaco) {
                    resolve();
                } else {
                    setTimeout(checkMonaco, 100);
                }
            };

            checkMonaco();

            // Timeout after 10 seconds
            setTimeout(() => {
                if (!window.monaco) {
                    reject(new Error('Monaco Editor failed to load'));
                }
            }, 10000);
        });
    }

    initializeEditor() {
        if (!this.container || !window.monaco) return;

        // Configure Monaco
        window.monaco.editor.defineTheme('cloud-ide-dark', {
            base: 'vs-dark',
            inherit: true,
            rules: [
                { token: 'comment', foreground: '6A9955' },
                { token: 'keyword', foreground: '569CD6' },
                { token: 'string', foreground: 'CE9178' },
                { token: 'number', foreground: 'B5CEA8' },
            ],
            colors: {
                'editor.background': '#1e1e1e',
                'editor.lineHighlightBackground': '#2d2d30',
                'editorCursor.foreground': '#007acc',
                'editor.selectionBackground': '#264f78',
                'editor.selectionHighlightBackground': '#173e43',
            }
        });

        window.monaco.editor.defineTheme('cloud-ide-light', {
            base: 'vs',
            inherit: true,
            rules: [
                { token: 'comment', foreground: '008000' },
                { token: 'keyword', foreground: '0000FF' },
                { token: 'string', foreground: 'A31515' },
                { token: 'number', foreground: '098658' },
            ],
            colors: {
                'editor.background': '#ffffff',
                'editor.lineHighlightBackground': '#f0f0f0',
                'editorCursor.foreground': '#0078d4',
                'editor.selectionBackground': '#add6ff',
            }
        });

        // Create editor instance
        this.editor = window.monaco.editor.create(this.container, {
            value: '',
            language: 'javascript',
            theme: this.theme === 'vs-dark' ? 'cloud-ide-dark' : 'cloud-ide-light',
            fontSize: this.fontSize,
            fontFamily: "'Fira Code', 'Monaco', 'Cascadia Code', monospace",
            fontLigatures: true,
            wordWrap: this.wordWrap,
            lineNumbers: 'on',
            automaticLayout: true,
            minimap: { enabled: true },
            scrollBeyondLastLine: false,
            renderWhitespace: 'selection',
            rulers: [80, 120],
            folding: true,
            foldingStrategy: 'indentation',
            showFoldingControls: 'always',
            bracketPairColorization: { enabled: true },
            guides: {
                bracketPairs: true,
                indentation: true
            },
            suggest: {
                enabled: true,
                showKeywords: true,
                showSnippets: true
            },
            quickSuggestions: {
                other: true,
                comments: false,
                strings: false
            },
            parameterHints: { enabled: true },
            formatOnPaste: true,
            formatOnType: true,
            autoIndent: 'full',
            tabSize: 2,
            insertSpaces: true,
            detectIndentation: true
        });

        // Set up editor event listeners
        this.setupEditorEventListeners();
    }

    setupEditorEventListeners() {
        if (!this.editor) return;

        // Content change
        this.editor.onDidChangeModelContent((e) => {
            if (this.activeTab) {
                const tab = this.openTabs.get(this.activeTab);
                if (tab) {
                    tab.modified = true;
                    tab.content = this.editor.getValue();
                    this.updateTabStatus(this.activeTab, true);
                    this.onFileChange(this.activeTab, tab.content);
                }
            }
        });

        // Cursor position change
        this.editor.onDidChangeCursorPosition((e) => {
            this.updateStatusBar(e.position);
        });

        // Model change (when switching files)
        this.editor.onDidChangeModel((e) => {
            if (e.newModelUrl) {
                const filePath = e.newModelUrl.path;
                this.setActiveTab(filePath);
            }
        });

        // Key bindings
        this.editor.addCommand(window.monaco.KeyMod.CtrlCmd | window.monaco.KeyCode.KeyS, () => {
            this.saveCurrentFile();
        });

        this.editor.addCommand(window.monaco.KeyMod.CtrlCmd | window.monaco.KeyCode.KeyW, () => {
            if (this.activeTab) {
                this.closeTab(this.activeTab);
            }
        });

        this.editor.addCommand(window.monaco.KeyMod.CtrlCmd | window.monaco.KeyMod.Shift | window.monaco.KeyCode.KeyP, () => {
            this.showCommandPalette();
        });
    }

    setupEventListeners() {
        // Window resize
        window.addEventListener('resize', () => {
            if (this.editor) {
                this.editor.layout();
            }
        });

        // Theme change
        window.addEventListener('themechange', (e) => {
            this.updateTheme(e.detail.theme);
        });

        // Tab container events
        if (this.tabContainer) {
            this.tabContainer.addEventListener('click', (e) => {
                const tab = e.target.closest('.tab');
                const closeBtn = e.target.closest('.tab-close');
                
                if (closeBtn) {
                    e.stopPropagation();
                    const filePath = tab.dataset.path;
                    this.closeTab(filePath);
                } else if (tab) {
                    const filePath = tab.dataset.path;
                    this.setActiveTab(filePath);
                }
            });
        }
    }

    async openFile(filePath) {
        if (!this.isInitialized) {
            this.pendingFiles.push(filePath);
            return;
        }

        try {
            // Check if file is already open
            if (this.openTabs.has(filePath)) {
                this.setActiveTab(filePath);
                return;
            }

            // Fetch file content
            const response = await fetch(`/api/files/content?path=${encodeURIComponent(filePath)}`);
            if (!response.ok) {
                throw new Error(`Failed to load file: ${response.statusText}`);
            }

            const data = await response.json();
            if (!data.success) {
                throw new Error(data.error || 'Failed to load file content');
            }
            
            // Determine language from file extension
            const language = this.getLanguageFromFilePath(filePath);
            
            // Create Monaco model
            const uri = window.monaco.Uri.parse(`file://${filePath}`);
            let model = window.monaco.editor.getModel(uri);
            
            if (!model) {
                model = window.monaco.editor.createModel(
                    data.data.content,
                    language,
                    uri
                );
            }

            // Create tab
            const tab = {
                path: filePath,
                name: this.getFileName(filePath),
                content: data.data.content,
                language: language,
                model: model,
                modified: false,
                lastSaved: data.data.modified,
                size: data.data.size
            };

            this.openTabs.set(filePath, tab);
            this.createTab(tab);
            this.setActiveTab(filePath);
            this.hideWelcome();

        } catch (error) {
            console.error('Error opening file:', error);
            this.showNotification('Failed to open file: ' + error.message, 'error');
        }
    }

    createTab(tab) {
        if (!this.tabContainer) return;

        const tabElement = document.createElement('div');
        tabElement.className = 'tab';
        tabElement.dataset.path = tab.path;
        tabElement.title = tab.path;

        tabElement.innerHTML = `
            <i class="tab-icon ${this.getFileIconClass(tab.name)}"></i>
            <span class="tab-name">${tab.name}</span>
            <button class="tab-close" title="Close">
                <i class="fas fa-times"></i>
            </button>
        `;

        this.tabContainer.appendChild(tabElement);
    }

    setActiveTab(filePath) {
        if (!this.openTabs.has(filePath)) return;

        const tab = this.openTabs.get(filePath);
        
        // Update UI
        this.updateTabSelection(filePath);
        
        // Set editor model
        if (this.editor && tab.model) {
            this.editor.setModel(tab.model);
            this.editor.focus();
        }

        this.activeTab = filePath;
        this.updateStatusBar();
    }

    updateTabSelection(activePath) {
        if (!this.tabContainer) return;

        // Remove active class from all tabs
        this.tabContainer.querySelectorAll('.tab').forEach(tab => {
            tab.classList.remove('active');
        });

        // Add active class to selected tab
        const activeTab = this.tabContainer.querySelector(`[data-path="${activePath}"]`);
        if (activeTab) {
            activeTab.classList.add('active');
        }
    }

    updateTabStatus(filePath, modified) {
        const tabElement = this.tabContainer?.querySelector(`[data-path="${filePath}"]`);
        if (tabElement) {
            tabElement.classList.toggle('modified', modified);
        }
    }

    async closeTab(filePath) {
        if (!this.openTabs.has(filePath)) return;

        const tab = this.openTabs.get(filePath);
        
        // Check for unsaved changes
        if (tab.modified) {
            const shouldSave = confirm(`Save changes to ${tab.name}?`);
            if (shouldSave) {
                await this.saveFile(filePath);
            }
        }

        // Remove from tabs
        this.openTabs.delete(filePath);
        
        // Remove tab element
        const tabElement = this.tabContainer?.querySelector(`[data-path="${filePath}"]`);
        if (tabElement) {
            tabElement.remove();
        }

        // Dispose Monaco model
        if (tab.model) {
            tab.model.dispose();
        }

        // If this was the active tab, switch to another or show welcome
        if (this.activeTab === filePath) {
            const remainingTabs = Array.from(this.openTabs.keys());
            if (remainingTabs.length > 0) {
                this.setActiveTab(remainingTabs[remainingTabs.length - 1]);
            } else {
                this.activeTab = null;
                this.showWelcome();
            }
        }
    }

    async saveCurrentFile() {
        if (!this.activeTab) return;
        await this.saveFile(this.activeTab);
    }

    async saveFile(filePath) {
        if (!this.openTabs.has(filePath)) return;

        const tab = this.openTabs.get(filePath);
        
        try {
            await this.onFileSave(filePath, tab.content);
            
            tab.modified = false;
            tab.lastSaved = new Date().toISOString();
            this.updateTabStatus(filePath, false);
            
            this.showNotification(`Saved ${tab.name}`, 'success');
            
        } catch (error) {
            console.error('Error saving file:', error);
            this.showNotification('Failed to save file: ' + error.message, 'error');
        }
    }

    closeAllTabs() {
        const filePaths = Array.from(this.openTabs.keys());
        filePaths.forEach(filePath => this.closeTab(filePath));
    }

    renameFile(oldPath, newPath) {
        if (!this.openTabs.has(oldPath)) return;

        const tab = this.openTabs.get(oldPath);
        tab.path = newPath;
        tab.name = this.getFileName(newPath);
        tab.language = this.getLanguageFromFilePath(newPath);

        // Update tab
        this.openTabs.delete(oldPath);
        this.openTabs.set(newPath, tab);

        // Update tab element
        const tabElement = this.tabContainer?.querySelector(`[data-path="${oldPath}"]`);
        if (tabElement) {
            tabElement.dataset.path = newPath;
            tabElement.title = newPath;
            tabElement.querySelector('.tab-name').textContent = tab.name;
            tabElement.querySelector('.tab-icon').className = `tab-icon ${this.getFileIconClass(tab.name)}`;
        }

        // Update active tab reference
        if (this.activeTab === oldPath) {
            this.activeTab = newPath;
        }

        // Update Monaco model language
        if (tab.model) {
            window.monaco.editor.setModelLanguage(tab.model, tab.language);
        }
    }

    getLanguageFromFilePath(filePath) {
        const extension = filePath.split('.').pop()?.toLowerCase();
        
        const languageMap = {
            'js': 'javascript',
            'jsx': 'javascript',
            'mjs': 'javascript',
            'ts': 'typescript',
            'tsx': 'typescript',
            'html': 'html',
            'htm': 'html',
            'css': 'css',
            'scss': 'scss',
            'sass': 'sass',
            'less': 'less',
            'json': 'json',
            'md': 'markdown',
            'py': 'python',
            'java': 'java',
            'php': 'php',
            'go': 'go',
            'rs': 'rust',
            'cpp': 'cpp',
            'c': 'c',
            'cs': 'csharp',
            'rb': 'ruby',
            'vue': 'vue',
            'xml': 'xml',
            'yaml': 'yaml',
            'yml': 'yaml',
            'sql': 'sql',
            'sh': 'shell',
            'bash': 'shell',
            'ps1': 'powershell',
            'dockerfile': 'dockerfile',
            'env': 'shell'
        };

        return languageMap[extension] || 'plaintext';
    }

    getFileName(filePath) {
        return filePath.split('/').pop() || 'untitled';
    }

    getFileIconClass(fileName) {
        const extension = fileName.split('.').pop()?.toLowerCase();
        
        const iconMap = {
            'js': 'file-js',
            'jsx': 'file-react',
            'ts': 'file-typescript',
            'tsx': 'file-react',
            'html': 'file-html',
            'css': 'file-css',
            'scss': 'file-sass',
            'json': 'file-json',
            'md': 'file-markdown',
            'py': 'file-python',
            'java': 'file-java',
            'php': 'file-php',
            'go': 'file-go',
            'rs': 'file-rust',
            'vue': 'file-vue'
        };

        return iconMap[extension] || 'file-generic';
    }

    updateStatusBar(position) {
        // This would update a status bar if we had one
        if (position) {
            console.log(`Line ${position.lineNumber}, Column ${position.column}`);
        }
    }

    updateTheme(theme) {
        this.theme = theme;
        if (this.editor) {
            const monacoTheme = theme === 'light' ? 'cloud-ide-light' : 'cloud-ide-dark';
            window.monaco.editor.setTheme(monacoTheme);
        }
    }

    showWelcome() {
        if (this.welcomeContainer) {
            this.welcomeContainer.style.display = 'flex';
        }
        if (this.container) {
            this.container.style.display = 'none';
        }
    }

    hideWelcome() {
        if (this.welcomeContainer) {
            this.welcomeContainer.style.display = 'none';
        }
        if (this.container) {
            this.container.style.display = 'block';
        }
    }

    showError(message) {
        if (this.container) {
            this.container.innerHTML = `
                <div class="editor-error">
                    <i class="fas fa-exclamation-triangle"></i>
                    <h3>Editor Error</h3>
                    <p>${message}</p>
                    <button onclick="location.reload()" class="btn">Reload Page</button>
                </div>
            `;
        }
    }

    showNotification(message, type = 'info') {
        // This would show a notification - integrate with notification service
        console.log(`[${type.toUpperCase()}] ${message}`);
    }

    showCommandPalette() {
        // Future implementation for command palette
        console.log('Command palette would open here');
    }

    resize() {
        if (this.editor) {
            this.editor.layout();
        }
    }

    // Editor settings
    setFontSize(size) {
        this.fontSize = size;
        if (this.editor) {
            this.editor.updateOptions({ fontSize: size });
        }
    }

    setWordWrap(wrap) {
        this.wordWrap = wrap;
        if (this.editor) {
            this.editor.updateOptions({ wordWrap: wrap });
        }
    }

    toggleMinimap() {
        if (this.editor) {
            const current = this.editor.getOptions().get(window.monaco.editor.EditorOption.minimap);
            this.editor.updateOptions({
                minimap: { enabled: !current.enabled }
            });
        }
    }

    // Search and replace
    showFindReplace() {
        if (this.editor) {
            this.editor.getAction('actions.find').run();
        }
    }

    // Code formatting
    async formatDocument() {
        if (this.editor) {
            await this.editor.getAction('editor.action.formatDocument').run();
        }
    }

    // Go to line
    showGoToLine() {
        if (this.editor) {
            this.editor.getAction('editor.action.gotoLine').run();
        }
    }

    // Public API
    getValue() {
        return this.editor?.getValue() || '';
    }

    setValue(value) {
        if (this.editor) {
            this.editor.setValue(value);
        }
    }

    getActiveFilePath() {
        return this.activeTab;
    }

    getOpenFiles() {
        return Array.from(this.openTabs.keys());
    }

    hasUnsavedChanges() {
        return Array.from(this.openTabs.values()).some(tab => tab.modified);
    }

    async saveAll() {
        const savePromises = [];
        for (const [filePath, tab] of this.openTabs) {
            if (tab.modified) {
                savePromises.push(this.saveFile(filePath));
            }
        }
        await Promise.all(savePromises);
    }
}