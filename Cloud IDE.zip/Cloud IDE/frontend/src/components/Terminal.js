// frontend/src/components/Terminal.js

/**
 * Terminal Component
 * Handles xterm.js integration with WebSocket backend
 */
export class Terminal {
    constructor(options) {
        this.container = options.container;
        this.tabContainer = options.tabContainer;
        this.ws = options.ws;
        this.onTerminalCreate = options.onTerminalCreate || (() => {});
        this.onTerminalDestroy = options.onTerminalDestroy || (() => {});
        
        this.terminals = new Map();
        this.activeTerminal = null;
        this.terminalCounter = 0;
        this.isVisible = false;
        
        this.setupEventListeners();
    }

    async init() {
        try {
            // Load xterm.js
            await this.loadXterm();
            
            // Create initial terminal
            this.createTerminal();
            
        } catch (error) {
            console.error('Failed to initialize terminal:', error);
            this.showError('Failed to initialize terminal');
        }
    }

    async loadXterm() {
        return new Promise((resolve, reject) => {
            if (window.Terminal) {
                resolve();
                return;
            }

            // Check if xterm is loaded
            const checkXterm = () => {
                if (window.Terminal) {
                    resolve();
                } else {
                    setTimeout(checkXterm, 100);
                }
            };

            checkXterm();

            // Timeout after 10 seconds
            setTimeout(() => {
                if (!window.Terminal) {
                    reject(new Error('Xterm.js failed to load'));
                }
            }, 10000);
        });
    }

    setupEventListeners() {
        // WebSocket events
        if (this.ws) {
            this.ws.on('terminal-output', this.handleTerminalOutput.bind(this));
            this.ws.on('terminal-created', this.handleTerminalCreated.bind(this));
            this.ws.on('terminal-exit', this.handleTerminalExit.bind(this));
            this.ws.on('connected', this.handleWebSocketConnect.bind(this));
            this.ws.on('disconnected', this.handleWebSocketDisconnect.bind(this));
        }

        // Tab container events
        if (this.tabContainer) {
            this.tabContainer.addEventListener('click', (e) => {
                const tab = e.target.closest('.terminal-tab');
                const closeBtn = e.target.closest('.terminal-tab-close');
                
                if (closeBtn) {
                    e.stopPropagation();
                    const terminalId = tab.dataset.id;
                    this.closeTerminal(terminalId);
                } else if (tab) {
                    const terminalId = tab.dataset.id;
                    this.setActiveTerminal(terminalId);
                }
            });
        }

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            // Ctrl+` to toggle terminal
            if ((e.ctrlKey || e.metaKey) && e.key === '`') {
                e.preventDefault();
                this.toggle();
            }
            
            // Ctrl+Shift+` to create new terminal
            if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === '`') {
                e.preventDefault();
                this.createTerminal();
            }
        });

        // Window resize
        window.addEventListener('resize', () => {
            this.resizeActiveTerminal();
        });
    }

    createTerminal(id = null) {
        const terminalId = id || `terminal-${++this.terminalCounter}`;
        
        try {
            // Create xterm instance
            const terminal = new window.Terminal({
                rows: 24,
                cols: 80,
                cursorBlink: true,
                cursorStyle: 'block',
                fontFamily: "'Fira Code', 'Monaco', 'Cascadia Code', monospace",
                fontSize: 14,
                fontWeight: 'normal',
                fontWeightBold: 'bold',
                lineHeight: 1.2,
                letterSpacing: 0,
                theme: this.getTerminalTheme(),
                allowTransparency: true,
                scrollback: 1000,
                tabStopWidth: 4,
                convertEol: true
            });

            // Create terminal container
            const terminalElement = document.createElement('div');
            terminalElement.className = 'terminal-instance';
            terminalElement.dataset.id = terminalId;
            terminalElement.style.display = 'none';

            // Create terminal wrapper
            const wrapper = document.createElement('div');
            wrapper.className = 'xterm-terminal';
            terminalElement.appendChild(wrapper);

            // Open terminal in container
            terminal.open(wrapper);

            // Load addons
            this.loadTerminalAddons(terminal);

            // Store terminal data
            const terminalData = {
                id: terminalId,
                terminal: terminal,
                element: terminalElement,
                wrapper: wrapper,
                connected: false,
                title: `Terminal ${this.terminalCounter}`,
                cwd: '/workspace'
            };

            this.terminals.set(terminalId, terminalData);

            // Add to DOM
            if (this.container) {
                this.container.appendChild(terminalElement);
            }

            // Create tab
            this.createTerminalTab(terminalData);

            // Set up terminal event listeners
            this.setupTerminalEventListeners(terminalData);

            // Request backend terminal creation if WebSocket is connected
            if (this.ws && this.ws.isConnected()) {
                this.ws.send('create-terminal', { id: terminalId });
            } else {
                // Show offline mode
                this.showOfflineMessage(terminalData);
            }

            // Set as active
            this.setActiveTerminal(terminalId);
            
            // Show terminal if hidden
            if (!this.isVisible) {
                this.show();
            }

            this.onTerminalCreate(terminalId);
            return terminalId;

        } catch (error) {
            console.error('Error creating terminal:', error);
            this.showNotification('Failed to create terminal', 'error');
            return null;
        }
    }

    loadTerminalAddons(terminal) {
        try {
            // Fit addon for auto-sizing
            if (window.FitAddon) {
                const fitAddon = new window.FitAddon.FitAddon();
                terminal.loadAddon(fitAddon);
                terminal.fitAddon = fitAddon;
            }

            // Web links addon
            if (window.WebLinksAddon) {
                const webLinksAddon = new window.WebLinksAddon.WebLinksAddon();
                terminal.loadAddon(webLinksAddon);
            }

            // Search addon
            if (window.SearchAddon) {
                const searchAddon = new window.SearchAddon.SearchAddon();
                terminal.loadAddon(searchAddon);
                terminal.searchAddon = searchAddon;
            }

        } catch (error) {
            console.warn('Some terminal addons failed to load:', error);
        }
    }

    setupTerminalEventListeners(terminalData) {
        const { terminal, id } = terminalData;

        // Data input from user
        terminal.onData((data) => {
            if (this.ws && this.ws.isConnected()) {
                this.ws.send('terminal-input', { id, input: data });
            }
        });

        // Terminal resize
        terminal.onResize((dimensions) => {
            if (this.ws && this.ws.isConnected()) {
                this.ws.send('terminal-resize', {
                    id,
                    cols: dimensions.cols,
                    rows: dimensions.rows
                });
            }
        });

        // Title change
        terminal.onTitleChange((title) => {
            terminalData.title = title || `Terminal ${id}`;
            this.updateTerminalTab(id);
        });

        // Selection change
        terminal.onSelectionChange(() => {
            const selection = terminal.getSelection();
            if (selection) {
                // Could implement copy on selection here
            }
        });

        // Right click context menu
        terminalData.wrapper.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            this.showTerminalContextMenu(e, terminalData);
        });
    }

    createTerminalTab(terminalData) {
        if (!this.tabContainer) return;

        const tab = document.createElement('div');
        tab.className = 'terminal-tab';
        tab.dataset.id = terminalData.id;
        tab.title = terminalData.title;

        tab.innerHTML = `
            <div class="terminal-tab-content">
                <i class="terminal-tab-icon fas fa-terminal"></i>
                <span class="terminal-tab-name">${terminalData.title}</span>
                <button class="terminal-tab-close" title="Close Terminal">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;

        this.tabContainer.appendChild(tab);
    }

    updateTerminalTab(terminalId) {
        const terminalData = this.terminals.get(terminalId);
        if (!terminalData) return;

        const tab = this.tabContainer?.querySelector(`[data-id="${terminalId}"]`);
        if (tab) {
            const nameElement = tab.querySelector('.terminal-tab-name');
            if (nameElement) {
                nameElement.textContent = terminalData.title;
            }
            tab.title = terminalData.title;
        }
    }

    setActiveTerminal(terminalId) {
        if (!this.terminals.has(terminalId)) return;

        // Hide all terminals
        this.terminals.forEach((data, id) => {
            data.element.style.display = 'none';
            
            // Update tab appearance
            const tab = this.tabContainer?.querySelector(`[data-id="${id}"]`);
            if (tab) {
                tab.classList.remove('active');
            }
        });

        // Show active terminal
        const terminalData = this.terminals.get(terminalId);
        terminalData.element.style.display = 'block';
        
        // Update tab appearance
        const activeTab = this.tabContainer?.querySelector(`[data-id="${terminalId}"]`);
        if (activeTab) {
            activeTab.classList.add('active');
        }

        // Focus terminal
        terminalData.terminal.focus();
        
        // Resize to fit
        this.fitTerminal(terminalId);

        this.activeTerminal = terminalId;
    }

    closeTerminal(terminalId) {
        const terminalData = this.terminals.get(terminalId);
        if (!terminalData) return;

        // Kill backend terminal
        if (this.ws && this.ws.isConnected()) {
            this.ws.send('kill-terminal', { id: terminalId });
        }

        // Dispose xterm instance
        terminalData.terminal.dispose();

        // Remove from DOM
        if (terminalData.element.parentNode) {
            terminalData.element.parentNode.removeChild(terminalData.element);
        }

        // Remove tab
        const tab = this.tabContainer?.querySelector(`[data-id="${terminalId}"]`);
        if (tab) {
            tab.remove();
        }

        // Remove from terminals map
        this.terminals.delete(terminalId);

        // If this was active terminal, switch to another or hide
        if (this.activeTerminal === terminalId) {
            const remainingTerminals = Array.from(this.terminals.keys());
            if (remainingTerminals.length > 0) {
                this.setActiveTerminal(remainingTerminals[remainingTerminals.length - 1]);
            } else {
                this.activeTerminal = null;
                this.hide();
            }
        }

        this.onTerminalDestroy(terminalId);
    }

    // WebSocket event handlers
    handleTerminalOutput(data) {
        const { id, data: output } = data;
        const terminalData = this.terminals.get(id);
        
        if (terminalData) {
            terminalData.terminal.write(output);
            terminalData.connected = true;
        }
    }

    handleTerminalCreated(data) {
        const { id } = data;
        const terminalData = this.terminals.get(id);
        
        if (terminalData) {
            terminalData.connected = true;
            this.hideOfflineMessage(terminalData);
        }
    }

    handleTerminalExit(data) {
        const { id, code } = data;
        const terminalData = this.terminals.get(id);
        
        if (terminalData) {
            terminalData.terminal.write(`\r\n\x1b[31mTerminal exited with code ${code}\x1b[0m\r\n`);
            terminalData.connected = false;
        }
    }

    handleWebSocketConnect() {
        // Reconnect all terminals
        this.terminals.forEach((terminalData, id) => {
            if (!terminalData.connected) {
                this.ws.send('create-terminal', { id });
            }
        });
    }

    handleWebSocketDisconnect() {
        // Mark all terminals as disconnected
        this.terminals.forEach((terminalData) => {
            terminalData.connected = false;
            this.showOfflineMessage(terminalData);
        });
    }

    showOfflineMessage(terminalData) {
        terminalData.terminal.write('\x1b[33mTerminal offline - waiting for connection...\x1b[0m\r\n');
    }

    hideOfflineMessage(terminalData) {
        terminalData.terminal.clear();
        terminalData.terminal.write('Connected to Cloud IDE Terminal\r\n\r\n');
    }

    // Terminal management
    fitTerminal(terminalId) {
        const terminalData = this.terminals.get(terminalId);
        if (terminalData && terminalData.terminal.fitAddon) {
            setTimeout(() => {
                terminalData.terminal.fitAddon.fit();
            }, 100);
        }
    }

    resizeActiveTerminal() {
        if (this.activeTerminal) {
            this.fitTerminal(this.activeTerminal);
        }
    }

    clearTerminal(terminalId = this.activeTerminal) {
        const terminalData = this.terminals.get(terminalId);
        if (terminalData) {
            terminalData.terminal.clear();
        }
    }

    // Theme management
    getTerminalTheme() {
        const isDark = document.body.classList.contains('theme-dark');
        
        if (isDark) {
            return {
                background: '#1e1e1e',
                foreground: '#cccccc',
                cursor: '#007acc',
                cursorAccent: '#000000',
                selection: 'rgba(255, 255, 255, 0.2)',
                black: '#000000',
                red: '#cd3131',
                green: '#0dbc79',
                yellow: '#e5e510',
                blue: '#2472c8',
                magenta: '#bc3fbc',
                cyan: '#11a8cd',
                white: '#e5e5e5',
                brightBlack: '#666666',
                brightRed: '#f14c4c',
                brightGreen: '#23d18b',
                brightYellow: '#f5f543',
                brightBlue: '#3b8eea',
                brightMagenta: '#d670d6',
                brightCyan: '#29b8db',
                brightWhite: '#e5e5e5'
            };
        } else {
            return {
                background: '#ffffff',
                foreground: '#333333',
                cursor: '#0078d4',
                cursorAccent: '#ffffff',
                selection: 'rgba(0, 0, 0, 0.2)',
                black: '#000000',
                red: '#cd3131',
                green: '#00bc00',
                yellow: '#949800',
                blue: '#0451a5',
                magenta: '#bc05bc',
                cyan: '#0598bc',
                white: '#555555',
                brightBlack: '#666666',
                brightRed: '#cd3131',
                brightGreen: '#14ce14',
                brightYellow: '#b5ba00',
                brightBlue: '#0451a5',
                brightMagenta: '#bc05bc',
                brightCyan: '#0598bc',
                brightWhite: '#a5a5a5'
            };
        }
    }

    updateTheme() {
        const newTheme = this.getTerminalTheme();
        this.terminals.forEach((terminalData) => {
            terminalData.terminal.options.theme = newTheme;
        });
    }

    // Context menu
    showTerminalContextMenu(event, terminalData) {
        const menu = document.createElement('div');
        menu.className = 'terminal-context-menu';
        menu.style.position = 'fixed';
        menu.style.left = event.clientX + 'px';
        menu.style.top = event.clientY + 'px';
        menu.style.zIndex = '10000';

        const selection = terminalData.terminal.getSelection();
        
        menu.innerHTML = `
            <div class="terminal-context-item" data-action="copy" ${!selection ? 'class="disabled"' : ''}>
                <i class="fas fa-copy"></i>
                <span>Copy</span>
            </div>
            <div class="terminal-context-item" data-action="paste">
                <i class="fas fa-paste"></i>
                <span>Paste</span>
            </div>
            <div class="terminal-context-separator"></div>
            <div class="terminal-context-item" data-action="clear">
                <i class="fas fa-broom"></i>
                <span>Clear Terminal</span>
            </div>
    
            <div class="terminal-context-item" data-action="new-terminal">
                <i class="fas fa-plus"></i>
                <span>New Terminal</span>
            </div>
            <div class="terminal-context-item" data-action="close-terminal">
                <i class="fas fa-times"></i>
                <span>Close Terminal</span>
            </div>
        `;

        document.body.appendChild(menu);

        // Handle menu clicks
        menu.addEventListener('click', async (e) => {
            const item = e.target.closest('.terminal-context-item');
            if (!item || item.classList.contains('disabled')) return;

            const action = item.dataset.action;
            
            switch (action) {
                case 'copy':
                    await this.copySelection(terminalData);
                    break;
                case 'paste':
                    await this.pasteFromClipboard(terminalData);
                    break;
                case 'clear':
                    this.clearTerminal(terminalData.id);
                    break;
                case 'new-terminal':
                    this.createTerminal();
                    break;
                case 'close-terminal':
                    this.closeTerminal(terminalData.id);
                    break;
            }
            
            menu.remove();
        });

        // Remove menu on outside click
        setTimeout(() => {
            document.addEventListener('click', () => menu.remove(), { once: true });
        }, 0);
    }

    async copySelection(terminalData) {
        const selection = terminalData.terminal.getSelection();
        if (selection) {
            try {
                await navigator.clipboard.writeText(selection);
                this.showNotification('Copied to clipboard', 'success');
            } catch (error) {
                console.error('Failed to copy:', error);
            }
        }
    }

    async pasteFromClipboard(terminalData) {
        try {
            const text = await navigator.clipboard.readText();
            if (text && this.ws && this.ws.isConnected()) {
                this.ws.send('terminal-input', { id: terminalData.id, input: text });
            }
        } catch (error) {
            console.error('Failed to paste:', error);
        }
    }

    // Search functionality
    showSearch(terminalId = this.activeTerminal) {
        const terminalData = this.terminals.get(terminalId);
        if (terminalData && terminalData.terminal.searchAddon) {
            // Create search overlay
            const searchOverlay = document.createElement('div');
            searchOverlay.className = 'terminal-search';
            searchOverlay.innerHTML = `
                <input type="text" class="terminal-search-input" placeholder="Search terminal...">
                <div class="terminal-search-controls">
                    <div class="terminal-search-buttons">
                        <button class="terminal-search-button" data-action="previous" title="Previous">
                            <i class="fas fa-chevron-up"></i>
                        </button>
                        <button class="terminal-search-button" data-action="next" title="Next">
                            <i class="fas fa-chevron-down"></i>
                        </button>
                        <button class="terminal-search-button" data-action="close" title="Close">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="terminal-search-results"></div>
                </div>
            `;

            terminalData.element.appendChild(searchOverlay);
            searchOverlay.classList.add('visible');

            const input = searchOverlay.querySelector('.terminal-search-input');
            const resultsElement = searchOverlay.querySelector('.terminal-search-results');
            
            input.focus();

            // Search functionality
            let currentIndex = 0;
            let matches = [];

            const performSearch = (query) => {
                if (!query) {
                    matches = [];
                    resultsElement.textContent = '';
                    return;
                }

                // Use search addon if available
                if (terminalData.terminal.searchAddon) {
                    const found = terminalData.terminal.searchAddon.findNext(query);
                    if (found) {
                        resultsElement.textContent = 'Found';
                    } else {
                        resultsElement.textContent = 'Not found';
                    }
                }
            };

            // Event listeners
            input.addEventListener('input', (e) => {
                performSearch(e.target.value);
            });

            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    if (e.shiftKey) {
                        // Previous
                        if (terminalData.terminal.searchAddon) {
                            terminalData.terminal.searchAddon.findPrevious(input.value);
                        }
                    } else {
                        // Next
                        if (terminalData.terminal.searchAddon) {
                            terminalData.terminal.searchAddon.findNext(input.value);
                        }
                    }
                } else if (e.key === 'Escape') {
                    searchOverlay.remove();
                }
            });

            searchOverlay.addEventListener('click', (e) => {
                const button = e.target.closest('.terminal-search-button');
                if (!button) return;

                const action = button.dataset.action;
                switch (action) {
                    case 'previous':
                        if (terminalData.terminal.searchAddon) {
                            terminalData.terminal.searchAddon.findPrevious(input.value);
                        }
                        break;
                    case 'next':
                        if (terminalData.terminal.searchAddon) {
                            terminalData.terminal.searchAddon.findNext(input.value);
                        }
                        break;
                    case 'close':
                        searchOverlay.remove();
                        break;
                }
            });
        }
    }

    // Public API methods
    show() {
        const panel = document.getElementById('terminal-panel');
        if (panel) {
            panel.style.display = 'flex';
            this.isVisible = true;
            
            // Resize active terminal after showing
            setTimeout(() => {
                this.resizeActiveTerminal();
            }, 100);
        }
    }

    hide() {
        const panel = document.getElementById('terminal-panel');
        if (panel) {
            panel.style.display = 'none';
            this.isVisible = false;
        }
    }

    toggle() {
        if (this.isVisible) {
            this.hide();
        } else {
            this.show();
            
            // Create terminal if none exist
            if (this.terminals.size === 0) {
                this.createTerminal();
            }
        }
    }

    newTerminal() {
        return this.createTerminal();
    }

    resize() {
        this.terminals.forEach((terminalData, id) => {
            this.fitTerminal(id);
        });
    }

    // Settings
    setFontSize(size) {
        this.terminals.forEach((terminalData) => {
            terminalData.terminal.options.fontSize = size;
        });
    }

    setFontFamily(family) {
        this.terminals.forEach((terminalData) => {
            terminalData.terminal.options.fontFamily = family;
        });
    }

    // Utility methods
    showError(message) {
        if (this.container) {
            this.container.innerHTML = `
                <div class="terminal-error">
                    <i class="fas fa-exclamation-triangle"></i>
                    <h3>Terminal Error</h3>
                    <p>${message}</p>
                    <button onclick="location.reload()" class="btn">Reload Page</button>
                </div>
            `;
        }
    }

    showNotification(message, type = 'info') {
        // Integrate with notification service
        console.log(`[${type.toUpperCase()}] ${message}`);
    }

    // Cleanup
    destroy() {
        // Close all terminals
        this.terminals.forEach((terminalData, id) => {
            this.closeTerminal(id);
        });

        // Remove event listeners
        document.removeEventListener('keydown', this.handleKeydown);
        window.removeEventListener('resize', this.handleResize);
    }

    // Status and info
    getActiveTerminalId() {
        return this.activeTerminal;
    }

    getTerminalCount() {
        return this.terminals.size;
    }

    getTerminalInfo(terminalId) {
        const terminalData = this.terminals.get(terminalId);
        return terminalData ? {
            id: terminalData.id,
            title: terminalData.title,
            connected: terminalData.connected,
            cwd: terminalData.cwd
        } : null;
    }

    getAllTerminals() {
        return Array.from(this.terminals.keys()).map(id => this.getTerminalInfo(id));
    }

    // Commands
    sendCommand(command, terminalId = this.activeTerminal) {
        if (this.ws && this.ws.isConnected() && terminalId) {
            this.ws.send('terminal-input', { id: terminalId, input: command + '\r' });
        }
    }

    // Keyboard shortcuts handler
    handleKeyboard(e) {
        const terminalData = this.terminals.get(this.activeTerminal);
        if (!terminalData) return;

        // Ctrl+Shift+F - Search
        if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'F') {
            e.preventDefault();
            this.showSearch();
        }
        
        // Ctrl+Shift+C - Copy (if there's a selection)
        if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'C') {
            e.preventDefault();
            this.copySelection(terminalData);
        }
        
        // Ctrl+Shift+V - Paste
        if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'V') {
            e.preventDefault();
            this.pasteFromClipboard(terminalData);
        }
        
        // Ctrl+L - Clear
        if ((e.ctrlKey || e.metaKey) && e.key === 'l') {
            e.preventDefault();
            this.clearTerminal();
        }
    }
}