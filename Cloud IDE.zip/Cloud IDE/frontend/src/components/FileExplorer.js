// frontend/src/components/FileExplorer.js

/**
 * File Explorer Component
 * Handles file tree display and file operations
 */
export class FileExplorer {
    constructor(options) {
        this.container = options.container;
        this.api = options.api;
        this.onFileSelect = options.onFileSelect || (() => {});
        this.onFileCreate = options.onFileCreate || (() => {});
        this.onFileDelete = options.onFileDelete || (() => {});
        this.onFileRename = options.onFileRename || (() => {});
        
        this.fileTree = new Map();
        this.selectedItem = null;
        this.expandedItems = new Set();
        this.contextMenu = null;
        
        this.setupEventListeners();
    }

    async init() {
        await this.loadFileTree();
        this.setupDragAndDrop();
    }

    async loadFileTree(path = '/') {
        try {
            this.showLoading();
            const response = await this.api.get('/api/files/tree', { params: { path } });
            
            if (response.success) {
                this.fileTree = this.buildFileTree(response.data.tree);
                this.render();
            } else {
                throw new Error(response.error || 'Failed to load file tree');
            }
        } catch (error) {
            console.error('Error loading file tree:', error);
            this.showError('Failed to load files');
        } finally {
            this.hideLoading();
        }
    }

    buildFileTree(treeData) {
        const fileMap = new Map();
        
        const processNode = (node, path = '', level = 0) => {
            const fullPath = path ? `${path}/${node.name}` : node.name;
            
            const fileItem = {
                name: node.name,
                path: fullPath,
                type: node.type,
                size: node.size,
                modified: node.modified,
                level: level,
                children: [],
                expanded: this.expandedItems.has(fullPath)
            };

            if (node.children) {
                fileItem.children = node.children.map(child => 
                    processNode(child, fullPath, level + 1)
                );
            }

            fileMap.set(fullPath, fileItem);
            return fileItem;
        };

        return processNode(treeData);
    }

    render() {
        if (!this.container) return;

        this.container.innerHTML = '';
        this.renderFileItem(this.fileTree, this.container);
    }

    renderFileItem(item, container) {
        const itemElement = this.createFileItemElement(item);
        container.appendChild(itemElement);

        // Render children if expanded
        if (item.expanded && item.children.length > 0) {
            const childrenContainer = document.createElement('div');
            childrenContainer.className = 'file-children';
            
            item.children.forEach(child => {
                this.renderFileItem(child, childrenContainer);
            });
            
            container.appendChild(childrenContainer);
        }
    }

    createFileItemElement(item) {
        const element = document.createElement('div');
        element.className = 'file-item';
        element.dataset.path = item.path;
        element.dataset.type = item.type;
        
        if (item.children.length > 0) {
            element.classList.add('has-children');
        }
        
        if (item.expanded) {
            element.classList.add('expanded');
        }

        // Create item content
        const content = document.createElement('div');
        content.className = 'file-item-content';
        
        // Expand arrow for directories
        if (item.type === 'directory') {
            const arrow = document.createElement('div');
            arrow.className = 'expand-arrow';
            arrow.innerHTML = '<i class="fas fa-chevron-right"></i>';
            content.appendChild(arrow);
        } else {
            // Spacer for files
            const spacer = document.createElement('div');
            spacer.className = 'expand-arrow';
            content.appendChild(spacer);
        }

        // File icon
        const icon = document.createElement('div');
        icon.className = `file-icon ${item.type} ${this.getFileIconClass(item)}`;
        icon.innerHTML = this.getFileIcon(item);
        content.appendChild(icon);

        // File name
        const name = document.createElement('div');
        name.className = 'file-name';
        name.textContent = item.name;
        name.title = item.path;
        content.appendChild(name);

        // File actions
        const actions = document.createElement('div');
        actions.className = 'file-actions';
        
        if (item.type === 'directory') {
            actions.innerHTML = `
                <button class="file-action" data-action="new-file" title="New File">
                    <i class="fas fa-file-plus"></i>
                </button>
                <button class="file-action" data-action="new-folder" title="New Folder">
                    <i class="fas fa-folder-plus"></i>
                </button>
            `;
        }
        
        actions.innerHTML += `
            <button class="file-action" data-action="rename" title="Rename">
                <i class="fas fa-edit"></i>
            </button>
            <button class="file-action" data-action="delete" title="Delete">
                <i class="fas fa-trash"></i>
            </button>
        `;
        
        content.appendChild(actions);
        element.appendChild(content);

        // Set up event listeners
        this.setupItemEventListeners(element, item);

        return element;
    }

    setupItemEventListeners(element, item) {
        const content = element.querySelector('.file-item-content');
        const arrow = element.querySelector('.expand-arrow');
        const actions = element.querySelectorAll('.file-action');

        // Click to select/expand
        content.addEventListener('click', (e) => {
            if (e.target.closest('.file-action')) return;
            
            this.selectItem(item.path);
            
            if (item.type === 'directory') {
                this.toggleExpand(item.path);
            } else {
                this.onFileSelect(item.path);
            }
        });

        // Double click to open file
        content.addEventListener('dblclick', (e) => {
            if (item.type === 'file') {
                this.onFileSelect(item.path);
            }
        });

        // Arrow click
        if (arrow && item.type === 'directory') {
            arrow.addEventListener('click', (e) => {
                e.stopPropagation();
                this.toggleExpand(item.path);
            });
        }

        // Action buttons
        actions.forEach(button => {
            button.addEventListener('click', (e) => {
                e.stopPropagation();
                const action = button.dataset.action;
                this.handleAction(action, item);
            });
        });

        // Context menu
        content.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            this.showContextMenu(e, item);
        });
    }

    selectItem(path) {
        // Remove previous selection
        const previousSelected = this.container.querySelector('.file-item.selected');
        if (previousSelected) {
            previousSelected.classList.remove('selected');
        }

        // Add selection to new item
        const item = this.container.querySelector(`[data-path="${path}"]`);
        if (item) {
            item.classList.add('selected');
            this.selectedItem = path;
        }
    }

    async toggleExpand(path) {
        const item = this.findItem(path);
        if (!item || item.type !== 'directory') return;

        if (this.expandedItems.has(path)) {
            this.expandedItems.delete(path);
        } else {
            this.expandedItems.add(path);
        }

        // Re-render the tree
        await this.loadFileTree();
    }

    findItem(path) {
        const findInTree = (item) => {
            if (item.path === path) return item;
            
            for (const child of item.children) {
                const found = findInTree(child);
                if (found) return found;
            }
            
            return null;
        };

        return findInTree(this.fileTree);
    }

    async handleAction(action, item) {
        switch (action) {
            case 'new-file':
                await this.createFile(item.path);
                break;
            case 'new-folder':
                await this.createFolder(item.path);
                break;
            case 'rename':
                await this.renameItem(item);
                break;
            case 'delete':
                await this.deleteItem(item);
                break;
        }
    }

    async createFile(parentPath = '/') {
        const fileName = prompt('Enter file name:');
        if (!fileName) return;

        try {
            const filePath = parentPath === '/' ? `/${fileName}` : `${parentPath}/${fileName}`;
            
            await this.api.post('/api/files/content', {
                path: filePath,
                content: ''
            });

            this.onFileCreate(filePath, false);
            await this.refresh();
        } catch (error) {
            console.error('Error creating file:', error);
            alert('Failed to create file: ' + error.message);
        }
    }

    async createFolder(parentPath = '/') {
        const folderName = prompt('Enter folder name:');
        if (!folderName) return;

        try {
            const folderPath = parentPath === '/' ? `/${folderName}` : `${parentPath}/${folderName}`;
            
            await this.api.post('/api/files/directory', {
                path: folderPath
            });

            this.onFileCreate(folderPath, true);
            await this.refresh();
        } catch (error) {
            console.error('Error creating folder:', error);
            alert('Failed to create folder: ' + error.message);
        }
    }

    async renameItem(item) {
        const newName = prompt('Enter new name:', item.name);
        if (!newName || newName === item.name) return;

        try {
            const pathParts = item.path.split('/');
            pathParts[pathParts.length - 1] = newName;
            const newPath = pathParts.join('/');

            await this.api.post('/api/files/rename', {
                oldPath: item.path,
                newPath: newPath
            });

            this.onFileRename(item.path, newPath);
            await this.refresh();
        } catch (error) {
            console.error('Error renaming item:', error);
            alert('Failed to rename: ' + error.message);
        }
    }

    async deleteItem(item) {
        const confirmMessage = item.type === 'directory' 
            ? `Delete folder "${item.name}" and all its contents?`
            : `Delete file "${item.name}"?`;
            
        if (!confirm(confirmMessage)) return;

        try {
            await this.api.delete('/api/files', {
                data: { path: item.path }
            });

            this.onFileDelete(item.path);
            await this.refresh();
        } catch (error) {
            console.error('Error deleting item:', error);
            alert('Failed to delete: ' + error.message);
        }
    }

    showContextMenu(event, item) {
        this.hideContextMenu();

        const contextMenu = document.createElement('div');
        contextMenu.className = 'context-menu';
        contextMenu.style.position = 'fixed';
        contextMenu.style.left = event.clientX + 'px';
        contextMenu.style.top = event.clientY + 'px';
        contextMenu.style.zIndex = '10000';

        const menuItems = this.getContextMenuItems(item);
        contextMenu.innerHTML = menuItems.map(menuItem => {
            if (menuItem.separator) {
                return '<div class="context-menu-separator"></div>';
            }
            return `
                <div class="context-menu-item" data-action="${menuItem.action}">
                    <i class="${menuItem.icon}"></i>
                    <span>${menuItem.label}</span>
                    ${menuItem.shortcut ? `<span class="context-menu-shortcut">${menuItem.shortcut}</span>` : ''}
                </div>
            `;
        }).join('');

        document.body.appendChild(contextMenu);
        this.contextMenu = contextMenu;

        // Add event listeners
        contextMenu.addEventListener('click', (e) => {
            const menuItem = e.target.closest('.context-menu-item');
            if (menuItem) {
                const action = menuItem.dataset.action;
                this.handleAction(action, item);
                this.hideContextMenu();
            }
        });

        // Hide on outside click
        setTimeout(() => {
            document.addEventListener('click', this.hideContextMenu.bind(this), { once: true });
        }, 0);
    }

    getContextMenuItems(item) {
        const items = [];

        if (item.type === 'file') {
            items.push(
                { action: 'open', label: 'Open', icon: 'fas fa-external-link-alt' },
                { action: 'open-with', label: 'Open With...', icon: 'fas fa-cog' },
                { separator: true }
            );
        }

        if (item.type === 'directory') {
            items.push(
                { action: 'new-file', label: 'New File', icon: 'fas fa-file-plus', shortcut: 'Ctrl+N' },
                { action: 'new-folder', label: 'New Folder', icon: 'fas fa-folder-plus', shortcut: 'Ctrl+Shift+N' },
                { separator: true }
            );
        }

        items.push(
            { action: 'rename', label: 'Rename', icon: 'fas fa-edit', shortcut: 'F2' },
            { action: 'delete', label: 'Delete', icon: 'fas fa-trash', shortcut: 'Del' },
            { separator: true },
            { action: 'copy-path', label: 'Copy Path', icon: 'fas fa-copy' },
            { action: 'reveal', label: 'Reveal in Explorer', icon: 'fas fa-external-link-alt' }
        );

        return items;
    }

    hideContextMenu() {
        if (this.contextMenu) {
            this.contextMenu.remove();
            this.contextMenu = null;
        }
    }

    setupDragAndDrop() {
        this.container.addEventListener('dragover', this.handleDragOver.bind(this));
        this.container.addEventListener('drop', this.handleDrop.bind(this));
        this.container.addEventListener('dragstart', this.handleDragStart.bind(this));
    }

    handleDragOver(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        
        const target = e.target.closest('.file-item');
        if (target && target.dataset.type === 'directory') {
            target.classList.add('drag-over');
        }
    }

    handleDrop(e) {
        e.preventDefault();
        
        // Remove drag-over class from all items
        this.container.querySelectorAll('.drag-over').forEach(item => {
            item.classList.remove('drag-over');
        });

        const target = e.target.closest('.file-item');
        if (!target || target.dataset.type !== 'directory') return;

        const sourceePath = e.dataTransfer.getData('text/plain');
        const targetPath = target.dataset.path;

        if (sourcePath && targetPath && sourcePath !== targetPath) {
            this.moveItem(sourcePath, targetPath);
        }
    }

    handleDragStart(e) {
        const item = e.target.closest('.file-item');
        if (item) {
            e.dataTransfer.setData('text/plain', item.dataset.path);
            e.dataTransfer.effectAllowed = 'move';
        }
    }

    async moveItem(sourcePath, targetPath) {
        try {
            const sourceItem = this.findItem(sourcePath);
            if (!sourceItem) return;

            const newPath = `${targetPath}/${sourceItem.name}`;

            await this.api.post('/api/files/rename', {
                oldPath: sourcePath,
                newPath: newPath
            });

            await this.refresh();
        } catch (error) {
            console.error('Error moving item:', error);
            alert('Failed to move item: ' + error.message);
        }
    }

    getFileIcon(item) {
        if (item.type === 'directory') {
            return '<i class="fas fa-folder"></i>';
        }

        const extension = this.getFileExtension(item.name);
        const iconMap = {
            'js': '<i class="fab fa-js-square"></i>',
            'jsx': '<i class="fab fa-react"></i>',
            'ts': '<i class="fas fa-code"></i>',
            'tsx': '<i class="fab fa-react"></i>',
            'html': '<i class="fab fa-html5"></i>',
            'css': '<i class="fab fa-css3-alt"></i>',
            'scss': '<i class="fab fa-sass"></i>',
            'json': '<i class="fas fa-code"></i>',
            'md': '<i class="fab fa-markdown"></i>',
            'py': '<i class="fab fa-python"></i>',
            'java': '<i class="fab fa-java"></i>',
            'php': '<i class="fab fa-php"></i>',
            'go': '<i class="fas fa-code"></i>',
            'rs': '<i class="fas fa-code"></i>',
            'cpp': '<i class="fas fa-code"></i>',
            'c': '<i class="fas fa-code"></i>',
            'rb': '<i class="fas fa-gem"></i>',
            'vue': '<i class="fab fa-vuejs"></i>',
            'svg': '<i class="fas fa-image"></i>',
            'png': '<i class="fas fa-image"></i>',
            'jpg': '<i class="fas fa-image"></i>',
            'gif': '<i class="fas fa-image"></i>',
            'pdf': '<i class="fas fa-file-pdf"></i>',
            'zip': '<i class="fas fa-file-archive"></i>',
            'txt': '<i class="fas fa-file-alt"></i>'
        };

        return iconMap[extension] || '<i class="fas fa-file"></i>';
    }

    getFileIconClass(item) {
        if (item.type === 'directory') return 'folder';
        
        const extension = this.getFileExtension(item.name);
        return extension || 'file';
    }

    getFileExtension(filename) {
        const parts = filename.split('.');
        return parts.length > 1 ? parts.pop().toLowerCase() : '';
    }

    setupEventListeners() {
        // Global keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.target.closest('#file-tree')) {
                this.handleKeyboard(e);
            }
        });
    }

    handleKeyboard(e) {
        switch (e.key) {
            case 'F2':
                e.preventDefault();
                if (this.selectedItem) {
                    const item = this.findItem(this.selectedItem);
                    if (item) this.renameItem(item);
                }
                break;
            case 'Delete':
                e.preventDefault();
                if (this.selectedItem) {
                    const item = this.findItem(this.selectedItem);
                    if (item) this.deleteItem(item);
                }
                break;
            case 'Enter':
                e.preventDefault();
                if (this.selectedItem) {
                    const item = this.findItem(this.selectedItem);
                    if (item && item.type === 'file') {
                        this.onFileSelect(item.path);
                    }
                }
                break;
        }
    }

    showLoading() {
        if (this.container) {
            this.container.classList.add('loading');
        }
    }

    hideLoading() {
        if (this.container) {
            this.container.classList.remove('loading');
        }
    }

    showError(message) {
        if (this.container) {
            this.container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-exclamation-triangle"></i>
                    <h3>Error</h3>
                    <p>${message}</p>
                    <button onclick="this.parentElement.parentElement.dispatchEvent(new CustomEvent('retry'))" class="btn btn-small">
                        Retry
                    </button>
                </div>
            `;
            
            this.container.addEventListener('retry', () => {
                this.loadFileTree();
            }, { once: true });
        }
    }

    async refresh() {
        await this.loadFileTree();
    }

    // Public API methods
    newFile() {
        const parentPath = this.selectedItem || '/';
        const item = this.findItem(parentPath);
        const targetPath = item && item.type === 'directory' ? parentPath : '/';
        this.createFile(targetPath);
    }

    newFolder() {
        const parentPath = this.selectedItem || '/';
        const item = this.findItem(parentPath);
        const targetPath = item && item.type === 'directory' ? parentPath : '/';
        this.createFolder(targetPath);
    }
}