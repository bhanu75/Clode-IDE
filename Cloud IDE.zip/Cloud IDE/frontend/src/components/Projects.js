// frontend/src/components/Projects.js

/**
 * Projects Component
 * Handles project templates and project management
 */
export class Projects {
    constructor(options) {
        this.api = options.api;
        this.onProjectCreate = options.onProjectCreate || (() => {});
        this.onProjectOpen = options.onProjectOpen || (() => {});
        
        this.templates = new Map();
        this.projects = new Map();
        this.currentProject = null;
    }

    async init() {
        try {
            await this.loadTemplates();
            await this.loadProjects();
        } catch (error) {
            console.error('Failed to initialize projects:', error);
        }
    }

    async loadTemplates() {
        try {
            const response = await this.api.get('/api/projects/templates');
            
            if (response.success) {
                response.data.templates.forEach(template => {
                    this.templates.set(template.id, template);
                });
                console.log('Loaded project templates:', this.templates.size);
            }
        } catch (error) {
            console.error('Error loading templates:', error);
        }
    }

    async loadProjects() {
        try {
            const response = await this.api.get('/api/projects');
            
            if (response.success) {
                this.projects.clear();
                response.data.projects.forEach(project => {
                    this.projects.set(project.name, project);
                });
                console.log('Loaded projects:', this.projects.size);
            }
        } catch (error) {
            console.error('Error loading projects:', error);
        }
    }

    showTemplates() {
        this.showModal('project-templates-modal');
        this.renderTemplates();
    }

    renderTemplates() {
        const container = document.getElementById('template-grid');
        if (!container) return;

        const templates = Array.from(this.templates.values());
        
        container.innerHTML = templates.map(template => `
            <div class="template-card" onclick="IDE.projects.createProject('${template.id}')">
                <div class="template-icon">
                    ${this.getTemplateIcon(template.id)}
                </div>
                <div class="template-name">${template.name}</div>
                <div class="template-description">${template.description}</div>
                <div class="template-features">
                    ${this.getTemplateFeatures(template.id).map(feature => 
                        `<span class="template-feature">${feature}</span>`
                    ).join('')}
                </div>
            </div>
        `).join('');
    }

    getTemplateIcon(templateId) {
        const icons = {
            'react-vite': '⚛️',
            'react-typescript': '⚛️',
            'nextjs': '▲',
            'vue-vite': '💚',
            'angular': '🅰️',
            'express-api': '🚂',
            'nest-api': '🐱',
            'fastapi': '🐍',
            'django': '🐍',
            'spring-boot': '☕',
            'laravel': '🐘',
            'go-gin': '🐹',
            'rust-axum': '🦀',
            'vanilla-js': '🟨',
            'static-site': '📄'
        };

        return icons[templateId] || '📦';
    }

    getTemplateFeatures(templateId) {
        const features = {
            'react-vite': ['React 18', 'TypeScript', 'Vite', 'ESLint'],
            'react-typescript': ['React', 'TypeScript', 'Vite', 'Hot Reload'],
            'nextjs': ['React', 'TypeScript', 'SSR', 'Tailwind CSS'],
            'vue-vite': ['Vue 3', 'TypeScript', 'Vite', 'Composition API'],
            'angular': ['Angular 17', 'TypeScript', 'CLI', 'Material'],
            'express-api': ['Express.js', 'Node.js', 'REST API', 'CORS'],
            'nest-api': ['NestJS', 'TypeScript', 'Decorators', 'Swagger'],
            'fastapi': ['Python', 'FastAPI', 'Type Hints', 'Auto Docs'],
            'django': ['Python', 'Django', 'ORM', 'Admin Panel'],
            'spring-boot': ['Java', 'Spring Boot', 'JPA', 'Maven'],
            'laravel': ['PHP', 'Laravel', 'Eloquent', 'Blade'],
            'go-gin': ['Go', 'Gin Framework', 'Fast', 'Minimal'],
            'rust-axum': ['Rust', 'Axum', 'Tokio', 'Type Safe'],
            'vanilla-js': ['HTML5', 'CSS3', 'JavaScript', 'Simple'],
            'static-site': ['HTML', 'CSS', 'Responsive', 'Fast']
        };

        return features[templateId] || ['Basic Template'];
    }

    async createProject(templateId) {
        const template = this.templates.get(templateId);
        if (!template) {
            alert('Template not found');
            return;
        }

        const projectName = prompt(`Enter project name for ${template.name}:`);
        if (!projectName) return;

        // Validate project name
        if (!this.isValidProjectName(projectName)) {
            alert('Invalid project name. Use only letters, numbers, hyphens, and underscores.');
            return;
        }

        // Check if project already exists
        if (this.projects.has(projectName)) {
            alert('A project with this name already exists');
            return;
        }

        try {
            this.showCreationProgress(projectName, template.name);
            
            const response = await this.api.post('/api/projects', {
                name: projectName,
                template: templateId,
                description: `${template.name} project created with Cloud IDE`
            });

            if (response.success) {
                // Update projects list
                this.projects.set(projectName, response.data.project);
                
                // Close modal
                this.hideModal();
                
                // Notify success
                this.showNotification(`Project "${projectName}" created successfully!`, 'success');
                
                // Callback
                this.onProjectCreate(response.data.project);
                
                // Open project
                await this.openProject(projectName);
                
            } else {
                throw new Error(response.error || 'Failed to create project');
            }

        } catch (error) {
            console.error('Error creating project:', error);
            alert('Failed to create project: ' + error.message);
        } finally {
            this.hideCreationProgress();
        }
    }

    showCreationProgress(projectName, templateName) {
        const modal = document.getElementById('project-templates-modal');
        if (modal) {
            modal.innerHTML = `
                <div class="modal-header">
                    <h2>Creating Project</h2>
                </div>
                <div class="modal-content" style="text-align: center; padding: 3rem;">
                    <div class="loading-spinner" style="margin: 0 auto 2rem;"></div>
                    <h3>Creating "${projectName}"</h3>
                    <p>Setting up ${templateName} template...</p>
                    <div class="creation-steps">
                        <div class="step active">📁 Creating directory structure</div>
                        <div class="step">📦 Installing dependencies</div>
                        <div class="step">⚙️ Configuring project</div>
                        <div class="step">🎉 Finishing setup</div>
                    </div>
                </div>
            `;

            // Animate steps
            const steps = modal.querySelectorAll('.step');
            let currentStep = 0;

            const animateSteps = () => {
                if (currentStep < steps.length) {
                    steps[currentStep].classList.add('active');
                    currentStep++;
                    setTimeout(animateSteps, 1000);
                }
            };

            setTimeout(animateSteps, 500);
        }
    }

    hideCreationProgress() {
        // Will be handled by hideModal()
    }

    async openProject(projectName) {
        const project = this.projects.get(projectName);
        if (!project) {
            console.error('Project not found:', projectName);
            return;
        }

        try {
            this.currentProject = projectName;
            this.onProjectOpen(projectName);
            
            // Could trigger file tree refresh, etc.
            
        } catch (error) {
            console.error('Error opening project:', error);
            this.showNotification('Failed to open project', 'error');
        }
    }

    async deleteProject(projectName) {
        const project = this.projects.get(projectName);
        if (!project) return;

        const confirmDelete = confirm(`Delete project "${projectName}"? This cannot be undone.`);
        if (!confirmDelete) return;

        try {
            const response = await this.api.delete(`/api/projects/${projectName}`);
            
            if (response.success) {
                this.projects.delete(projectName);
                
                if (this.currentProject === projectName) {
                    this.currentProject = null;
                }
                
                this.showNotification(`Project "${projectName}" deleted`, 'success');
                
                // Refresh project list if shown
                this.refreshProjectList();
                
            } else {
                throw new Error(response.error || 'Failed to delete project');
            }

        } catch (error) {
            console.error('Error deleting project:', error);
            alert('Failed to delete project: ' + error.message);
        }
    }

    async cloneProject(sourceProjectName, newProjectName) {
        if (!newProjectName) {
            newProjectName = prompt(`Enter name for cloned project:`);
            if (!newProjectName) return;
        }

        if (!this.isValidProjectName(newProjectName)) {
            alert('Invalid project name');
            return;
        }

        if (this.projects.has(newProjectName)) {
            alert('Project name already exists');
            return;
        }

        try {
            // This would need backend support for cloning
            this.showNotification('Project cloning not yet implemented', 'warning');
            
        } catch (error) {
            console.error('Error cloning project:', error);
            alert('Failed to clone project: ' + error.message);
        }
    }

    // Project list management
    getRecentProjects(limit = 5) {
        const projects = Array.from(this.projects.values());
        return projects
            .sort((a, b) => new Date(b.lastModified) - new Date(a.lastModified))
            .slice(0, limit);
    }

    getAllProjects() {
        return Array.from(this.projects.values());
    }

    getProjectsByType(type) {
        return Array.from(this.projects.values())
            .filter(project => project.type === type);
    }

    searchProjects(query) {
        const lowerQuery = query.toLowerCase();
        return Array.from(this.projects.values())
            .filter(project => 
                project.name.toLowerCase().includes(lowerQuery) ||
                project.description.toLowerCase().includes(lowerQuery) ||
                project.framework.toLowerCase().includes(lowerQuery)
            );
    }

    // Project templates management
    getAvailableTemplates() {
        return Array.from(this.templates.values());
    }

    getTemplatesByCategory(category) {
        return Array.from(this.templates.values())
            .filter(template => this.getTemplateCategory(template.id) === category);
    }

    getTemplateCategory(templateId) {
        const categories = {
            'react-vite': 'frontend',
            'react-typescript': 'frontend',
            'nextjs': 'fullstack',
            'vue-vite': 'frontend',
            'angular': 'frontend',
            'express-api': 'backend',
            'nest-api': 'backend',
            'fastapi': 'backend',
            'django': 'backend',
            'spring-boot': 'backend',
            'laravel': 'backend',
            'go-gin': 'backend',
            'rust-axum': 'backend',
            'vanilla-js': 'frontend',
            'static-site': 'frontend'
        };

        return categories[templateId] || 'other';
    }

    // Validation
    isValidProjectName(name) {
        // Allow letters, numbers, hyphens, underscores
        // Must start with letter or number
        const regex = /^[a-zA-Z0-9][a-zA-Z0-9_-]*$/;
        return regex.test(name) && name.length >= 2 && name.length <= 50;
    }

    // Modal management
    showModal(modalId) {
        const overlay = document.getElementById('modal-overlay');
        const modal = document.getElementById(modalId);
        
        if (overlay && modal) {
            overlay.style.display = 'flex';
            
            // Hide all modals first
            overlay.querySelectorAll('.modal').forEach(m => {
                m.style.display = 'none';
            });
            
            // Show target modal
            modal.style.display = 'block';
        }
    }

    hideModal() {
        const overlay = document.getElementById('modal-overlay');
        if (overlay) {
            overlay.style.display = 'none';
        }
    }

    // Utility methods
    showNotification(message, type = 'info') {
        // This would integrate with the notification service
        console.log(`[${type.toUpperCase()}] ${message}`);
        
        // If notification service is available
        if (window.IDE && window.IDE.notifications) {
            window.IDE.notifications.show(message, type);
        }
    }

    refreshProjectList() {
        // Reload projects from backend
        this.loadProjects();
    }

    formatProjectSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diffMs = now - date;
        const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
        const diffDays = Math.floor(diffHours / 24);

        if (diffHours < 1) {
            return 'Just now';
        } else if (diffHours < 24) {
            return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
        } else if (diffDays < 7) {
            return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
        } else {
            return date.toLocaleDateString();
        }
    }

    // Project statistics
    getProjectStats() {
        const projects = Array.from(this.projects.values());
        const stats = {
            total: projects.length,
            byType: {},
            byFramework: {},
            totalSize: 0,
            recent: this.getRecentProjects(5).length
        };

        projects.forEach(project => {
            // Count by type
            stats.byType[project.type] = (stats.byType[project.type] || 0) + 1;
            
            // Count by framework
            stats.byFramework[project.framework] = (stats.byFramework[project.framework] || 0) + 1;
            
            // Sum sizes (if available)
            if (project.size) {
                stats.totalSize += project.size;
            }
        });

        return stats;
    }

    // Export/Import (future feature)
    async exportProject(projectName) {
        // This would create a downloadable archive of the project
        this.showNotification('Project export not yet implemented', 'warning');
    }

    async importProject(file) {
        // This would import a project from an uploaded file
        this.showNotification('Project import not yet implemented', 'warning');
    }

    // Current project management
    getCurrentProject() {
        return this.currentProject ? this.projects.get(this.currentProject) : null;
    }

    setCurrentProject(projectName) {
        if (this.projects.has(projectName)) {
            this.currentProject = projectName;
            this.onProjectOpen(projectName);
        }
    }
}