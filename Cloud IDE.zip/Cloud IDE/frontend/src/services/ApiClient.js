// frontend/src/services/ApiClient.js

/**
 * API Client for communicating with the backend
 */
export class ApiClient {
    constructor() {
        this.baseURL = 'http://localhost:3001';
        this.timeout = 30000; // 30 seconds
        this.headers = {
            'Content-Type': 'application/json'
        };
    }

    setBaseURL(url) {
        this.baseURL = url;
    }

    setAuthToken(token) {
        if (token) {
            this.headers['Authorization'] = `Bearer ${token}`;
        } else {
            delete this.headers['Authorization'];
        }
    }

    async request(method, endpoint, options = {}) {
        const url = `${this.baseURL}${endpoint}`;
        const config = {
            method: method.toUpperCase(),
            headers: { ...this.headers, ...options.headers },
            ...options
        };

        // Add query parameters for GET requests
        if (options.params && method.toUpperCase() === 'GET') {
            const params = new URLSearchParams(options.params);
            url += `?${params.toString()}`;
        }

        // Add body for non-GET requests
        if (options.data && method.toUpperCase() !== 'GET') {
            config.body = JSON.stringify(options.data);
        }

        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), this.timeout);
            
            config.signal = controller.signal;

            const response = await fetch(url, config);
            clearTimeout(timeoutId);

            if (!response.ok) {
                const error = await response.json().catch(() => ({ 
                    error: `HTTP ${response.status} ${response.statusText}` 
                }));
                throw new Error(error.error || error.message || 'Request failed');
            }

            const contentType = response.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
                return await response.json();
            }

            return await response.text();

        } catch (error) {
            if (error.name === 'AbortError') {
                throw new Error('Request timeout');
            }
            throw error;
        }
    }

    // Convenience methods
    async get(endpoint, options = {}) {
        return this.request('GET', endpoint, options);
    }

    async post(endpoint, data, options = {}) {
        return this.request('POST', endpoint, { ...options, data });
    }

    async put(endpoint, data, options = {}) {
        return this.request('PUT', endpoint, { ...options, data });
    }

    async patch(endpoint, data, options = {}) {
        return this.request('PATCH', endpoint, { ...options, data });
    }

    async delete(endpoint, options = {}) {
        return this.request('DELETE', endpoint, options);
    }

    // File-specific methods
    async uploadFile(file, targetPath = '/') {
        const formData = new FormData();
        formData.append('files', file);
        formData.append('targetPath', targetPath);

        return this.request('POST', '/api/files/upload', {
            body: formData,
            headers: {} // Let browser set Content-Type for FormData
        });
    }

    async downloadFile(filePath) {
        const response = await fetch(`${this.baseURL}/api/files/content?path=${encodeURIComponent(filePath)}`, {
            headers: this.headers
        });

        if (!response.ok) {
            throw new Error('Failed to download file');
        }

        return response.blob();
    }
}