// frontend/src/services/ThemeManager.js

/**
 * Theme Manager for handling different UI themes
 */
export class ThemeManager {
    constructor() {
        this.currentTheme = 'dark';
        this.themes = {
            dark: {
                name: 'Dark',
                class: 'theme-dark',
                icon: 'fas fa-moon'
            },
            light: {
                name: 'Light',
                class: 'theme-light',
                icon: 'fas fa-sun'
            },
            'high-contrast': {
                name: 'High Contrast',
                class: 'theme-high-contrast',
                icon: 'fas fa-adjust'
            }
        };
        this.storageKey = 'cloudide-theme';
    }

    async init() {
        // Load saved theme or detect system preference
        const savedTheme = this.loadTheme();
        const systemTheme = this.detectSystemTheme();
        
        this.currentTheme = savedTheme || systemTheme;
        this.applyTheme(this.currentTheme);
        
        // Listen for system theme changes
        this.setupSystemThemeListener();
    }

    loadTheme() {
        try {
            return localStorage.getItem(this.storageKey);
        } catch (error) {
            console.warn('Failed to load theme from localStorage:', error);
            return null;
        }
    }

    saveTheme(theme) {
        try {
            localStorage.setItem(this.storageKey, theme);
        } catch (error) {
            console.warn('Failed to save theme to localStorage:', error);
        }
    }

    detectSystemTheme() {
        if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            return 'dark';
        }
        return 'light';
    }

    setupSystemThemeListener() {
        if (window.matchMedia) {
            const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
            mediaQuery.addEventListener('change', (e) => {
                // Only auto-switch if user hasn't manually set a theme
                const savedTheme = this.loadTheme();
                if (!savedTheme) {
                    const newTheme = e.matches ? 'dark' : 'light';
                    this.setTheme(newTheme, false); // Don't save auto-detected theme
                }
            });
        }
    }

    applyTheme(theme) {
        const body = document.body;
        
        // Remove all theme classes
        Object.values(this.themes).forEach(themeData => {
            body.classList.remove(themeData.class);
        });
        
        // Add new theme class
        if (this.themes[theme]) {
            body.classList.add(this.themes[theme].class);
            this.updateThemeIcon(theme);
            this.updateMonacoTheme(theme);
        }
    }

    updateThemeIcon(theme) {
        const themeButton = document.querySelector('[onclick="IDE.actions.toggleTheme()"]');
        if (themeButton) {
            const icon = themeButton.querySelector('i');
            if (icon && this.themes[theme]) {
                icon.className = this.themes[theme].icon;
            }
        }
    }

    updateMonacoTheme(theme) {
        // Update Monaco Editor theme if it's loaded
        if (window.monaco && window.monaco.editor) {
            const monacoTheme = theme === 'light' ? 'vs' : 'vs-dark';
            window.monaco.editor.setTheme(monacoTheme);
        }
    }

    setTheme(theme, save = true) {
        if (!this.themes[theme]) {
            console.warn(`Unknown theme: ${theme}`);
            return;
        }

        this.currentTheme = theme;
        this.applyTheme(theme);
        
        if (save) {
            this.saveTheme(theme);
        }

        // Dispatch theme change event
        window.dispatchEvent(new CustomEvent('themechange', {
            detail: { theme, themeData: this.themes[theme] }
        }));
    }

    toggleTheme() {
        const themeKeys = Object.keys(this.themes);
        const currentIndex = themeKeys.indexOf(this.currentTheme);
        const nextIndex = (currentIndex + 1) % themeKeys.length;
        const nextTheme = themeKeys[nextIndex];
        
        this.setTheme(nextTheme);
    }

    getCurrentTheme() {
        return {
            id: this.currentTheme,
            ...this.themes[this.currentTheme]
        };
    }

    getAllThemes() {
        return Object.entries(this.themes).map(([id, theme]) => ({
            id,
            ...theme
        }));
    }

    // CSS custom properties manipulation
    setCSSProperty(property, value) {
        document.documentElement.style.setProperty(property, value);
    }

    getCSSProperty(property) {
        return getComputedStyle(document.documentElement).getPropertyValue(property);
    }

    // High contrast mode detection
    isHighContrastMode() {
        return this.currentTheme === 'high-contrast' || 
               window.matchMedia('(prefers-contrast: high)').matches;
    }

    // Reduced motion detection
    prefersReducedMotion() {
        return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    }

    // Color scheme utilities
    getColorScheme() {
        switch (this.currentTheme) {
            case 'light':
                return 'light';
            case 'dark':
            case 'high-contrast':
                return 'dark';
            default:
                return 'dark';
        }
    }

    // Theme-aware color generation
    getThemeColor(colorName) {
        const colors = {
            primary: this.getCSSProperty('--primary-bg'),
            secondary: this.getCSSProperty('--secondary-bg'),
            accent: this.getCSSProperty('--accent-blue'),
            text: this.getCSSProperty('--text-primary'),
            border: this.getCSSProperty('--border-color')
        };
        
        return colors[colorName] || colors.primary;
    }
}