// frontend/src/services/NotificationService.js

/**
 * Notification Service for showing user notifications
 */
export class NotificationService {
    constructor() {
        this.container = null;
        this.notifications = new Map();
        this.defaultDuration = 5000; // 5 seconds
        this.maxNotifications = 5;
        this.init();
    }

    init() {
        this.container = document.getElementById('notifications');
        if (!this.container) {
            console.warn('Notifications container not found');
        }
    }

    show(message, type = 'info', options = {}) {
        const id = this.generateId();
        const duration = options.duration || this.defaultDuration;
        const persistent = options.persistent || false;
        const title = options.title || this.getDefaultTitle(type);

        const notification = this.createNotification(id, title, message, type, persistent);
        
        if (this.container) {
            // Remove oldest notification if we have too many
            if (this.notifications.size >= this.maxNotifications) {
                const oldestId = this.notifications.keys().next().value;
                this.remove(oldestId);
            }

            this.container.appendChild(notification.element);
            this.notifications.set(id, notification);

            // Auto-remove after duration (unless persistent)
            if (!persistent && duration > 0) {
                notification.timer = setTimeout(() => {
                    this.remove(id);
                }, duration);
            }
        }

        return id;
    }

    createNotification(id, title, message, type, persistent) {
        const element = document.createElement('div');
        element.className = `notification ${type}`;
        element.setAttribute('data-id', id);

        element.innerHTML = `
            <div class="notification-header">
                <span class="notification-title">${this.escapeHtml(title)}</span>
                <button class="notification-close" onclick="IDE.notifications.remove('${id}')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="notification-message">${this.escapeHtml(message)}</div>
            ${!persistent ? '<div class="notification-progress"></div>' : ''}
        `;

        return {
            id,
            element,
            type,
            persistent,
            timer: null,
            createdAt: Date.now()
        };
    }

    remove(id) {
        const notification = this.notifications.get(id);
        if (notification) {
            // Clear timer if exists
            if (notification.timer) {
                clearTimeout(notification.timer);
            }

            // Animate out
            notification.element.style.animation = 'slideOutRight 0.3s ease-in forwards';
            
            setTimeout(() => {
                if (notification.element.parentNode) {
                    notification.element.parentNode.removeChild(notification.element);
                }
                this.notifications.delete(id);
            }, 300);
        }
    }

    removeAll() {
        this.notifications.forEach((notification, id) => {
            this.remove(id);
        });
    }

    update(id, message, type) {
        const notification = this.notifications.get(id);
        if (notification) {
            const messageElement = notification.element.querySelector('.notification-message');
            if (messageElement) {
                messageElement.textContent = message;
            }
            
            // Update type class
            notification.element.className = `notification ${type}`;
            notification.type = type;
        }
    }

    // Convenience methods
    success(message, options = {}) {
        return this.show(message, 'success', options);
    }

    error(message, options = {}) {
        return this.show(message, 'error', { ...options, persistent: true });
    }

    warning(message, options = {}) {
        return this.show(message, 'warning', options);
    }

    info(message, options = {}) {
        return this.show(message, 'info', options);
    }

    // Helper methods
    generateId() {
        return 'notification-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
    }

    getDefaultTitle(type) {
        const titles = {
            success: 'Success',
            error: 'Error',
            warning: 'Warning',
            info: 'Information'
        };
        return titles[type] || 'Notification';
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Get all notifications
    getAll() {
        return Array.from(this.notifications.values());
    }

    // Get notifications by type
    getByType(type) {
        return Array.from(this.notifications.values()).filter(n => n.type === type);
    }

    // Clear by type
    clearByType(type) {
        this.notifications.forEach((notification, id) => {
            if (notification.type === type) {
                this.remove(id);
            }
        });
    }
}