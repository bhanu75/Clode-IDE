// frontend/src/services/WebSocketClient.js

/**
 * WebSocket Client for real-time communication
 */
export class WebSocketClient {
    constructor() {
        this.socket = null;
        this.url = 'ws://localhost:3001';
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.reconnectDelay = 1000;
        this.eventHandlers = new Map();
        this.connected = false;
    }

    setURL(url) {
        this.url = url;
    }

    async connect() {
        return new Promise((resolve, reject) => {
            try {
                this.socket = io(this.url, {
                    transports: ['websocket', 'polling'],
                    timeout: 20000,
                    reconnection: true,
                    reconnectionAttempts: this.maxReconnectAttempts,
                    reconnectionDelay: this.reconnectDelay
                });

                this.socket.on('connect', () => {
                    console.log('✅ WebSocket connected');
                    this.connected = true;
                    this.reconnectAttempts = 0;
                    this.emit('connected', { timestamp: Date.now() });
                    resolve();
                });

                this.socket.on('disconnect', (reason) => {
                    console.log('🔌 WebSocket disconnected:', reason);
                    this.connected = false;
                    this.emit('disconnected', { reason, timestamp: Date.now() });
                    
                    if (reason === 'io server disconnect') {
                        // Server disconnected, try to reconnect
                        this.reconnect();
                    }
                });

                this.socket.on('connect_error', (error) => {
                    console.error('❌ WebSocket connection error:', error);
                    this.connected = false;
                    this.emit('connection_error', { error: error.message, timestamp: Date.now() });
                    reject(error);
                });

                this.socket.on('reconnect', (attemptNumber) => {
                    console.log(`🔄 WebSocket reconnected after ${attemptNumber} attempts`);
                    this.connected = true;
                    this.emit('reconnected', { attempts: attemptNumber, timestamp: Date.now() });
                });

                this.socket.on('reconnect_error', (error) => {
                    console.error('❌ WebSocket reconnection error:', error);
                    this.emit('reconnect_error', { error: error.message, timestamp: Date.now() });
                });

                this.socket.on('reconnect_failed', () => {
                    console.error('❌ WebSocket reconnection failed');
                    this.connected = false;
                    this.emit('reconnect_failed', { timestamp: Date.now() });
                });

                // Set up event forwarding
                this.setupEventForwarding();

            } catch (error) {
                reject(error);
            }
        });
    }

    setupEventForwarding() {
        // File system events
        this.socket.on('file-added', (data) => this.emit('file-added', data));
        this.socket.on('file-changed', (data) => this.emit('file-changed', data));
        this.socket.on('file-deleted', (data) => this.emit('file-deleted', data));
        this.socket.on('directory-added', (data) => this.emit('directory-added', data));
        this.socket.on('directory-deleted', (data) => this.emit('directory-deleted', data));

        // Terminal events
        this.socket.on('terminal-output', (data) => this.emit('terminal-output', data));
        this.socket.on('terminal-created', (data) => this.emit('terminal-created', data));
        this.socket.on('terminal-exit', (data) => this.emit('terminal-exit', data));
        this.socket.on('terminal-killed', (data) => this.emit('terminal-killed', data));

        // Collaboration events
        this.socket.on('user-joined', (data) => this.emit('user-joined', data));
        this.socket.on('user-left', (data) => this.emit('user-left', data));
        this.socket.on('cursor-update', (data) => this.emit('cursor-update', data));
        this.socket.on('file-changes', (data) => this.emit('file-changes', data));
        this.socket.on('chat-message', (data) => this.emit('chat-message', data));

        // General events
        this.socket.on('error', (data) => this.emit('error', data));
        this.socket.on('notification', (data) => this.emit('notification', data));
    }

    disconnect() {
        if (this.socket) {
            this.socket.disconnect();
            this.socket = null;
            this.connected = false;
        }
    }

    // Event handling
    on(event, handler) {
        if (!this.eventHandlers.has(event)) {
            this.eventHandlers.set(event, []);
        }
        this.eventHandlers.get(event).push(handler);
    }

    off(event, handler) {
        if (this.eventHandlers.has(event)) {
            const handlers = this.eventHandlers.get(event);
            const index = handlers.indexOf(handler);
            if (index > -1) {
                handlers.splice(index, 1);
            }
        }
    }

    emit(event, data) {
        if (this.eventHandlers.has(event)) {
            this.eventHandlers.get(event).forEach(handler => {
                try {
                    handler(data);
                } catch (error) {
                    console.error(`Error in event handler for ${event}:`, error);
                }
            });
        }
    }

    // Send events to server
    send(event, data) {
        if (this.socket && this.connected) {
            this.socket.emit(event, data);
        } else {
            console.warn('WebSocket not connected, cannot send:', event, data);
        }
    }

    // Terminal methods
    createTerminal(id = 'default') {
        this.send('create-terminal', { id });
    }

    sendTerminalInput(id, input) {
        this.send('terminal-input', { id, input });
    }

    resizeTerminal(id, cols, rows) {
        this.send('terminal-resize', { id, cols, rows });
    }

    killTerminal(id) {
        this.send('kill-terminal', { id });
    }

    // File watching methods
    startFileWatching(path = '/') {
        this.send('watch-files', { path });
    }

    stopFileWatching() {
        this.send('stop-watch-files');
    }

    // Collaboration methods
    joinProject(projectId) {
        this.send('join-project', { projectId });
    }

    leaveProject(projectId) {
        this.send('leave-project', { projectId });
    }

    sendCursorPosition(projectId, filePath, line, column) {
        this.send('cursor-position', { projectId, filePath, line, column });
    }

    sendFileEdit(projectId, filePath, changes, version) {
        this.send('file-edit', { projectId, filePath, changes, version });
    }

    sendChatMessage(projectId, message, username) {
        this.send('chat-message', { projectId, message, username });
    }

    // Connection status
    isConnected() {
        return this.connected && this.socket && this.socket.connected;
    }

    // Manual reconnection
    reconnect() {
        if (this.socket) {
            this.socket.connect();
        } else {
            this.connect().catch(error => {
                console.error('Manual reconnection failed:', error);
            });
        }
    }
}