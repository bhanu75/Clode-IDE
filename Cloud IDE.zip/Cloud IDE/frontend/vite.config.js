// frontend/vite.config.js
import { defineConfig } from 'vite'

export default defineConfig({
  // Build configuration
  build: {
    target: 'es2015',
    outDir: 'dist',
    assetsDir: 'assets',
    sourcemap: false,
    minify: 'terser',
    terserOptions: {
      compress: {
        drop_console: true,
        drop_debugger: true
      }
    },
    rollupOptions: {
      output: {
        manualChunks: {
          // Vendor chunks for better caching
          'monaco': ['monaco-editor'],
          'xterm': ['xterm', 'xterm-addon-fit', 'xterm-addon-web-links', 'xterm-addon-search'],
          'socket': ['socket.io-client']
        }
      }
    },
    chunkSizeWarningLimit: 1000
  },

  // Development server
  server: {
    port: 5173,
    host: true,
    proxy: {
      '/api': {
        target: process.env.VITE_API_URL || 'http://localhost:3001',
        changeOrigin: true
      }
    }
  },

  // Environment variables
  define: {
    __APP_VERSION__: JSON.stringify(process.env.npm_package_version),
    __BUILD_TIME__: JSON.stringify(new Date().toISOString())
  },

  // Asset optimization
  assetsInclude: ['**/*.woff', '**/*.woff2'],

  // Plugins
  plugins: [
    // Add any Vite plugins here
  ],

  // CSS configuration
  css: {
    preprocessorOptions: {
      css: {
        charset: false
      }
    }
  },

  // Optimization
  optimizeDeps: {
    include: ['socket.io-client', 'xterm', 'monaco-editor']
  }
})