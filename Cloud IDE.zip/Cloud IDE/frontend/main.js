// frontend/src/main.js

/**
 * Cloud IDE - Main Application
 * Entry point for the web-based IDE
 */

// Import modules
import { FileExplorer } from './components/FileExplorer.js';
import { Editor } from './components/Editor.js';
import { Terminal } from './components/Terminal.js';
import { Projects } from './components/Projects.js';
import { WebSocketClient } from './services/WebSocketClient.js';
import { ApiClient } from './services/ApiClient.js';
import { NotificationService } from './services/NotificationService.js';
import { ThemeManager } from './services/ThemeManager.js';

class CloudIDE {
    constructor() {
        this.initialized = false;
        this.currentTheme = 'dark';
        
        // Core services
        this.api = new ApiClient();
        this.ws = new WebSocketClient();
        this.notifications = new NotificationService();
        this.themes = new ThemeManager();
        
        // Core components
        this.fileExplorer = null;
        this.editor = null;
        this.terminal = null;
        this.projects = null;
        
        // State management
        this.state = {
            currentProject: null,
            openFiles: new Map(),
            activeFile: null,
            sidebarVisible: true,
            terminalVisible: false,
            rightPanelVisible: false
        };
        
        // Event handlers
        this.eventHandlers = new Map();
        
        this.init();
    }

    async init() {
        try {
            console.log('🚀 Initializing Cloud IDE...');
            
            // Show loading screen
            this.showLoading('Initializing development environment...');
            
            // Initialize core services
            await this.initializeServices();
            
            // Initialize components
            await this.initializeComponents();
            
            // Set up event listeners
            this.setupEventListeners();
            
            // Set up keyboard shortcuts
            this.setupKeyboardShortcuts();
            
            // Connect to backend
            await this.connectToBackend();
            
            // Load initial data
            await this.loadInitialData();
            
            // Hide loading and show app
            this.hideLoading();
            
            this.initialized = true;
            console.log('✅ Cloud IDE initialized successfully');
            
            this.notifications.show('Welcome to Cloud IDE!', 'success');
            
        } catch (error) {
            console.error('❌ Failed to initialize Cloud IDE:', error);
            this.hideLoading();
            this.showError('Failed to initialize IDE', error.message);
        }
    }

    async initializeServices() {
        // Initialize theme manager
        await this.themes.init();
        
        // Initialize API client
        this.api.setBaseURL(import.meta.env.VITE_API_URL || 'http://localhost:3001');
        
        // Initialize WebSocket client
        this.ws.setURL(import.meta.env.VITE_WS_URL || 'ws://localhost:3001');
    }

    async initializeComponents() {
        // Initialize file explorer
        this.fileExplorer = new FileExplorer({
            container: document.getElementById('file-tree'),
            api: this.api,
            onFileSelect: this.handleFileSelect.bind(this),// frontend/src/main.js

/**
 * Cloud IDE - Main Application
 * Entry point for the web-based IDE
 */

// Import modules
import { FileExplorer } from './components/FileExplorer.js';
import { Editor } from './components/Editor.js';
import { Terminal } from './components/Terminal.js';
import { Projects } from './components/Projects.js';
import { WebSocketClient } from './services/WebSocketClient.js';
import { ApiClient } from './services/ApiClient.js';
import { NotificationService } from './services/NotificationService.js';
import { ThemeManager } from './services/ThemeManager.js';

class CloudIDE {
    constructor() {
        this.initialized = false;
        this.currentTheme = 'dark';
        
        // Core services
        this.api = new ApiClient();
        this.ws = new WebSocketClient();
        this.notifications = new NotificationService();
        this.themes = new ThemeManager();
        
        // Core components
        this.fileExplorer = null;
        this.editor = null;
        this.terminal = null;
        this.projects = null;
        
        // State management
        this.state = {
            currentProject: null,
            openFiles: new Map(),
            activeFile: null,
            sidebarVisible: true,
            terminalVisible: false,
            rightPanelVisible: false
        };
        
        // Event handlers
        this.eventHandlers = new Map();
        
        this.init();
    }

    async init() {
        try {
            console.log('🚀 Initializing Cloud IDE...');
            
            // Show loading screen
            this.showLoading('Initializing development environment...');
            
            // Initialize core services
            await this.initializeServices();
            
            // Initialize components
            await this.initializeComponents();
            
            // Set up event listeners
            this.setupEventListeners();
            
            // Set up keyboard shortcuts
            this.setupKeyboardShortcuts();
            
            // Connect to backend
            await this.connectToBackend();
            
            // Load initial data
            await this.loadInitialData();
            
            // Hide loading and show app
            this.hideLoading();
            
            this.initialized = true;
            console.log('✅ Cloud IDE initialized successfully');
            
            this.notifications.show('Welcome to Cloud IDE!', 'success');
            
        } catch (error) {
            console.error('❌ Failed to initialize Cloud IDE:',