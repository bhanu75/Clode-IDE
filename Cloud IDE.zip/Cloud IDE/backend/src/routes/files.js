// backend/src/routes/files.js
const express = require('express');
const fs = require('fs').promises;
const path = require('path');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');
const chokidar = require('chokidar');

const router = express.Router();

// File system utilities
const FileSystem = require('../utils/fileSystem');
const { validatePath, sanitizePath } = require('../utils/pathValidator');

// Configure multer for file uploads
const upload = multer({
  dest: process.env.UPLOAD_TEMP_PATH || '/tmp/uploads',
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE) || 10 * 1024 * 1024 // 10MB
  }
});

// Base workspace path
const WORKSPACE_PATH = process.env.WORKSPACE_PATH || '/workspace';

/**
 * GET /api/files/tree
 * Get complete file tree structure
 */
router.get('/tree', async (req, res) => {
  try {
    const { path: requestPath = '/' } = req.query;
    const safePath = sanitizePath(requestPath);
    const fullPath = path.join(WORKSPACE_PATH, safePath);

    if (!validatePath(fullPath, WORKSPACE_PATH)) {
      return res.status(400).json({ error: 'Invalid path' });
    }

    const tree = await FileSystem.getDirectoryTree(fullPath);
    
    res.json({
      success: true,
      data: {
        path: safePath,
        tree: tree
      }
    });
  } catch (error) {
    console.error('Error getting file tree:', error);
    res.status(500).json({ 
      error: 'Failed to get file tree',
      details: error.message 
    });
  }
});

/**
 * GET /api/files/content
 * Get file content
 */
router.get('/content', async (req, res) => {
  try {
    const { path: filePath } = req.query;
    
    if (!filePath) {
      return res.status(400).json({ error: 'File path is required' });
    }

    const safePath = sanitizePath(filePath);
    const fullPath = path.join(WORKSPACE_PATH, safePath);

    if (!validatePath(fullPath, WORKSPACE_PATH)) {
      return res.status(400).json({ error: 'Invalid file path' });
    }

    const content = await FileSystem.readFile(fullPath);
    const stats = await fs.stat(fullPath);

    res.json({
      success: true,
      data: {
        path: safePath,
        content: content,
        size: stats.size,
        modified: stats.mtime,
        encoding: 'utf8'
      }
    });
  } catch (error) {
    console.error('Error reading file:', error);
    
    if (error.code === 'ENOENT') {
      return res.status(404).json({ error: 'File not found' });
    }
    
    res.status(500).json({ 
      error: 'Failed to read file',
      details: error.message 
    });
  }
});

/**
 * POST /api/files/content
 * Create or update file content
 */
router.post('/content', async (req, res) => {
  try {
    const { path: filePath, content = '', encoding = 'utf8' } = req.body;

    if (!filePath) {
      return res.status(400).json({ error: 'File path is required' });
    }

    const safePath = sanitizePath(filePath);
    const fullPath = path.join(WORKSPACE_PATH, safePath);

    if (!validatePath(fullPath, WORKSPACE_PATH)) {
      return res.status(400).json({ error: 'Invalid file path' });
    }

    // Ensure directory exists
    const directory = path.dirname(fullPath);
    await fs.mkdir(directory, { recursive: true });

    // Write file content
    await fs.writeFile(fullPath, content, encoding);
    const stats = await fs.stat(fullPath);

    res.json({
      success: true,
      data: {
        path: safePath,
        size: stats.size,
        modified: stats.mtime,
        message: 'File saved successfully'
      }
    });
  } catch (error) {
    console.error('Error writing file:', error);
    res.status(500).json({ 
      error: 'Failed to save file',
      details: error.message 
    });
  }
});

/**
 * DELETE /api/files
 * Delete file or directory
 */
router.delete('/', async (req, res) => {
  try {
    const { path: targetPath } = req.body;

    if (!targetPath) {
      return res.status(400).json({ error: 'Path is required' });
    }

    const safePath = sanitizePath(targetPath);
    const fullPath = path.join(WORKSPACE_PATH, safePath);

    if (!validatePath(fullPath, WORKSPACE_PATH)) {
      return res.status(400).json({ error: 'Invalid path' });
    }

    await FileSystem.deleteFileOrDirectory(fullPath);

    res.json({
      success: true,
      data: {
        path: safePath,
        message: 'Deleted successfully'
      }
    });
  } catch (error) {
    console.error('Error deleting file/directory:', error);
    
    if (error.code === 'ENOENT') {
      return res.status(404).json({ error: 'File or directory not found' });
    }
    
    res.status(500).json({ 
      error: 'Failed to delete',
      details: error.message 
    });
  }
});

/**
 * POST /api/files/directory
 * Create directory
 */
router.post('/directory', async (req, res) => {
  try {
    const { path: dirPath } = req.body;

    if (!dirPath) {
      return res.status(400).json({ error: 'Directory path is required' });
    }

    const safePath = sanitizePath(dirPath);
    const fullPath = path.join(WORKSPACE_PATH, safePath);

    if (!validatePath(fullPath, WORKSPACE_PATH)) {
      return res.status(400).json({ error: 'Invalid directory path' });
    }

    await fs.mkdir(fullPath, { recursive: true });

    res.json({
      success: true,
      data: {
        path: safePath,
        message: 'Directory created successfully'
      }
    });
  } catch (error) {
    console.error('Error creating directory:', error);
    res.status(500).json({ 
      error: 'Failed to create directory',
      details: error.message 
    });
  }
});

/**
 * POST /api/files/upload
 * Upload files
 */
router.post('/upload', upload.array('files', 10), async (req, res) => {
  try {
    const { targetPath = '/' } = req.body;
    const files = req.files;

    if (!files || files.length === 0) {
      return res.status(400).json({ error: 'No files uploaded' });
    }

    const safePath = sanitizePath(targetPath);
    const targetDir = path.join(WORKSPACE_PATH, safePath);

    if (!validatePath(targetDir, WORKSPACE_PATH)) {
      return res.status(400).json({ error: 'Invalid target path' });
    }

    const uploadedFiles = [];

    for (const file of files) {
      const fileName = file.originalname;
      const destPath = path.join(targetDir, fileName);
      
      // Move file from temp location to target
      await fs.rename(file.path, destPath);
      
      uploadedFiles.push({
        name: fileName,
        path: path.join(safePath, fileName),
        size: file.size
      });
    }

    res.json({
      success: true,
      data: {
        uploadedFiles,
        message: `${uploadedFiles.length} files uploaded successfully`
      }
    });
  } catch (error) {
    console.error('Error uploading files:', error);
    res.status(500).json({ 
      error: 'Failed to upload files',
      details: error.message 
    });
  }
});

/**
 * POST /api/files/rename
 * Rename file or directory
 */
router.post('/rename', async (req, res) => {
  try {
    const { oldPath, newPath } = req.body;

    if (!oldPath || !newPath) {
      return res.status(400).json({ error: 'Both old and new paths are required' });
    }

    const safeOldPath = sanitizePath(oldPath);
    const safeNewPath = sanitizePath(newPath);
    
    const fullOldPath = path.join(WORKSPACE_PATH, safeOldPath);
    const fullNewPath = path.join(WORKSPACE_PATH, safeNewPath);

    if (!validatePath(fullOldPath, WORKSPACE_PATH) || !validatePath(fullNewPath, WORKSPACE_PATH)) {
      return res.status(400).json({ error: 'Invalid paths' });
    }

    await fs.rename(fullOldPath, fullNewPath);

    res.json({
      success: true,
      data: {
        oldPath: safeOldPath,
        newPath: safeNewPath,
        message: 'Renamed successfully'
      }
    });
  } catch (error) {
    console.error('Error renaming:', error);
    
    if (error.code === 'ENOENT') {
      return res.status(404).json({ error: 'Source file not found' });
    }
    
    res.status(500).json({ 
      error: 'Failed to rename',
      details: error.message 
    });
  }
});

/**
 * GET /api/files/search
 * Search files by name or content
 */
router.get('/search', async (req, res) => {
  try {
    const { query, type = 'name', path: searchPath = '/' } = req.query;

    if (!query) {
      return res.status(400).json({ error: 'Search query is required' });
    }

    const safePath = sanitizePath(searchPath);
    const fullPath = path.join(WORKSPACE_PATH, safePath);

    if (!validatePath(fullPath, WORKSPACE_PATH)) {
      return res.status(400).json({ error: 'Invalid search path' });
    }

    const results = await FileSystem.searchFiles(fullPath, query, type);

    res.json({
      success: true,
      data: {
        query,
        type,
        searchPath: safePath,
        results,
        count: results.length
      }
    });
  } catch (error) {
    console.error('Error searching files:', error);
    res.status(500).json({ 
      error: 'Search failed',
      details: error.message 
    });
  }
});

module.exports = router;