// backend/src/routes/projects.js
const express = require('express');
const fs = require('fs').promises;
const path = require('path');
const { spawn } = require('child_process');
const { v4: uuidv4 } = require('uuid');

const { sanitizePath, validatePath, isValidFilename } = require('../utils/pathValidator');

const router = express.Router();
const WORKSPACE_PATH = process.env.WORKSPACE_PATH || '/workspace';

/**
 * Project templates configuration
 */
const PROJECT_TEMPLATES = {
  'react-vite': {
    name: 'React + Vite',
    description: 'Modern React app with Vite bundler',
    command: 'npm create vite@latest',
    args: ['--template', 'react'],
    postInstall: ['npm install']
  },
  'react-typescript': {
    name: 'React + TypeScript',
    description: 'React app with TypeScript support',
    command: 'npm create vite@latest',
    args: ['--template', 'react-ts'],
    postInstall: ['npm install']
  },
  'nextjs': {
    name: 'Next.js',
    description: 'Full-stack React framework',
    command: 'npx create-next-app@latest',
    args: ['--typescript', '--tailwind', '--eslint', '--app'],
    postInstall: []
  },
  'express-api': {
    name: 'Express API',
    description: 'Node.js REST API with Express',
    command: 'npm init',
    args: ['-y'],
    postInstall: [
      'npm install express cors helmet morgan dotenv',
      'npm install -D nodemon'
    ]
  },
  'vue-vite': {
    name: 'Vue 3 + Vite',
    description: 'Vue.js 3 application with Vite',
    command: 'npm create vue@latest',
    args: [],
    postInstall: ['npm install']
  },
  'vanilla-js': {
    name: 'Vanilla JavaScript',
    description: 'Plain HTML, CSS, and JavaScript',
    command: null, // Will create manually
    args: [],
    postInstall: []
  }
};

/**
 * GET /api/projects
 * List all projects in workspace
 */
router.get('/', async (req, res) => {
  try {
    const projects = [];
    const items = await fs.readdir(WORKSPACE_PATH);

    for (const item of items) {
      const itemPath = path.join(WORKSPACE_PATH, item);
      const stats = await fs.stat(itemPath);

      if (stats.isDirectory()) {
        // Check if it's a project (has package.json or recognizable structure)
        const projectInfo = await getProjectInfo(itemPath);
        if (projectInfo) {
          projects.push({
            name: item,
            path: `/${item}`,
            ...projectInfo,
            lastModified: stats.mtime
          });
        }
      }
    }

    res.json({
      success: true,
      data: {
        projects,
        count: projects.length
      }
    });
  } catch (error) {
    console.error('Error listing projects:', error);
    res.status(500).json({
      error: 'Failed to list projects',
      details: error.message
    });
  }
});

/**
 * GET /api/projects/templates
 * Get available project templates
 */
router.get('/templates', (req, res) => {
  res.json({
    success: true,
    data: {
      templates: Object.entries(PROJECT_TEMPLATES).map(([key, template]) => ({
        id: key,
        ...template
      }))
    }
  });
});

/**
 * POST /api/projects
 * Create new project from template
 */
router.post('/', async (req, res) => {
  try {
    const { name, template, description = '' } = req.body;

    if (!name || !isValidFilename(name)) {
      return res.status(400).json({ error: 'Invalid project name' });
    }

    if (!template || !PROJECT_TEMPLATES[template]) {
      return res.status(400).json({ error: 'Invalid template' });
    }

    const safeName = sanitizePath(name);
    const projectPath = path.join(WORKSPACE_PATH, safeName);

    // Check if project already exists
    try {
      await fs.access(projectPath);
      return res.status(409).json({ error: 'Project already exists' });
    } catch (error) {
      // Project doesn't exist, continue
    }

    // Create project directory
    await fs.mkdir(projectPath, { recursive: true });

    const templateConfig = PROJECT_TEMPLATES[template];
    let projectInfo = {};

    if (template === 'vanilla-js') {
      // Create vanilla JS project structure
      await createVanillaProject(projectPath, name);
      projectInfo = {
        type: 'vanilla',
        framework: 'JavaScript',
        hasPackageJson: false
      };
    } else {
      // Create project using template command
      projectInfo = await createProjectFromTemplate(projectPath, name, templateConfig);
    }

    // Create project metadata
    const metadata = {
      id: uuidv4(),
      name,
      description,
      template,
      created: new Date().toISOString(),
      type: projectInfo.type || template,
      framework: projectInfo.framework || templateConfig.name
    };

    await fs.writeFile(
      path.join(projectPath, '.cloudide-project.json'),
      JSON.stringify(metadata, null, 2)
    );

    res.status(201).json({
      success: true,
      data: {
        project: {
          name,
          path: `/${safeName}`,
          ...metadata,
          ...projectInfo
        },
        message: 'Project created successfully'
      }
    });
  } catch (error) {
    console.error('Error creating project:', error);
    res.status(500).json({
      error: 'Failed to create project',
      details: error.message
    });
  }
});

/**
 * GET /api/projects/:name
 * Get specific project details
 */
router.get('/:name', async (req, res) => {
  try {
    const { name } = req.params;
    const safeName = sanitizePath(name);
    const projectPath = path.join(WORKSPACE_PATH, safeName);

    if (!validatePath(projectPath, WORKSPACE_PATH)) {
      return res.status(400).json({ error: 'Invalid project path' });
    }

    const projectInfo = await getProjectInfo(projectPath);
    if (!projectInfo) {
      return res.status(404).json({ error: 'Project not found' });
    }

    const stats = await fs.stat(projectPath);

    res.json({
      success: true,
      data: {
        name: safeName,
        path: `/${safeName}`,
        ...projectInfo,
        lastModified: stats.mtime
      }
    });
  } catch (error) {
    console.error('Error getting project:', error);
    res.status(500).json({
      error: 'Failed to get project',
      details: error.message
    });
  }
});

/**
 * DELETE /api/projects/:name
 * Delete project
 */
router.delete('/:name', async (req, res) => {
  try {
    const { name } = req.params;
    const safeName = sanitizePath(name);
    const projectPath = path.join(WORKSPACE_PATH, safeName);

    if (!validatePath(projectPath, WORKSPACE_PATH)) {
      return res.status(400).json({ error: 'Invalid project path' });
    }

    // Check if project exists
    try {
      await fs.access(projectPath);
    } catch (error) {
      return res.status(404).json({ error: 'Project not found' });
    }

    // Delete project directory
    await fs.rmdir(projectPath, { recursive: true });

    res.json({
      success: true,
      data: {
        name: safeName,
        message: 'Project deleted successfully'
      }
    });
  } catch (error) {
    console.error('Error deleting project:', error);
    res.status(500).json({
      error: 'Failed to delete project',
      details: error.message
    });
  }
});

/**
 * Helper function to get project information
 */
async function getProjectInfo(projectPath) {
  try {
    // Check for Cloud IDE metadata
    let metadata = {};
    try {
      const metadataPath = path.join(projectPath, '.cloudide-project.json');
      const metadataContent = await fs.readFile(metadataPath, 'utf8');
      metadata = JSON.parse(metadataContent);
    } catch (error) {
      // No metadata file, continue
    }

    // Check for package.json
    let packageInfo = {};
    let hasPackageJson = false;
    try {
      const packagePath = path.join(projectPath, 'package.json');
      const packageContent = await fs.readFile(packagePath, 'utf8');
      packageInfo = JSON.parse(packageContent);
      hasPackageJson = true;
    } catch (error) {
      // No package.json, might be vanilla project
    }

    // Determine project type
    let type = 'unknown';
    let framework = 'Unknown';

    if (hasPackageJson) {
      const dependencies = {
        ...packageInfo.dependencies,
        ...packageInfo.devDependencies
      };

      if (dependencies.react) {
        type = 'react';
        framework = dependencies.next ? 'Next.js' : 'React';
      } else if (dependencies.vue) {
        type = 'vue';
        framework = 'Vue.js';
      } else if (dependencies.express) {
        type = 'express';
        framework = 'Express.js';
      } else if (dependencies.angular) {
        type = 'angular';
        framework = 'Angular';
      } else {
        type = 'node';
        framework = 'Node.js';
      }
    } else {
      // Check for HTML files (vanilla project)
      try {
        const files = await fs.readdir(projectPath);
        if (files.some(file => file.endsWith('.html'))) {
          type = 'vanilla';
          framework = 'HTML/CSS/JS';
        }
      } catch (error) {
        // Directory might be empty
      }
    }

    return {
      id: metadata.id || uuidv4(),
      description: metadata.description || '',
      template: metadata.template || type,
      created: metadata.created || new Date().toISOString(),
      type,
      framework,
      hasPackageJson,
      packageInfo: hasPackageJson ? {
        name: packageInfo.name,
        version: packageInfo.version,
        scripts: packageInfo.scripts || {}
      } : null
    };
  } catch (error) {
    return null;
  }
}

/**
 * Helper function to create project from template
 */
async function createProjectFromTemplate(projectPath, name, templateConfig) {
  return new Promise((resolve, reject) => {
    const args = [name, ...templateConfig.args];
    const child = spawn(templateConfig.command.split(' ')[0], [
      ...templateConfig.command.split(' ').slice(1),
      ...args
    ], {
      cwd: path.dirname(projectPath),
      stdio: 'pipe'
    });

    let stdout = '';
    let stderr = '';

    child.stdout.on('data', (data) => {
      stdout += data.toString();
    });

    child.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    child.on('close', async (code) => {
      if (code !== 0) {
        reject(new Error(`Template creation failed: ${stderr}`));
        return;
      }

      try {
        // Run post-install commands
        for (const command of templateConfig.postInstall) {
          await runCommand(command, projectPath);
        }

        resolve({
          type: templateConfig.name.toLowerCase().includes('react') ? 'react' : 'node',
          framework: templateConfig.name,
          hasPackageJson: true
        });
      } catch (error) {
        reject(error);
      }
    });
  });
}

/**
 * Helper function to create vanilla JS project
 */
async function createVanillaProject(projectPath, name) {
  // Create basic HTML structure
  const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${name}</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Welcome to ${name}</h1>
        <p>Start building your awesome project!</p>
    </div>
    <script src="script.js"></script>
</body>
</html>`;

  const cssContent = `/* ${name} Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    line-height: 1.6;
    color: #333;
    background: #f4f4f4;
}

.container {
    max-width: 800px;
    margin: 0 auto;
    padding: 2rem;
    text-align: center;
}

h1 {
    color: #2c3e50;
    margin-bottom: 1rem;
}`;

  const jsContent = `// ${name} JavaScript
console.log('Welcome to ${name}!');

// Your awesome code goes here
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM fully loaded');
});`;

  await fs.writeFile(path.join(projectPath, 'index.html'), htmlContent);
  await fs.writeFile(path.join(projectPath, 'style.css'), cssContent);
  await fs.writeFile(path.join(projectPath, 'script.js'), jsContent);
}

/**
 * Helper function to run shell commands
 */
function runCommand(command, cwd) {
  return new Promise((resolve, reject) => {
    const child = spawn('sh', ['-c', command], { cwd, stdio: 'pipe' });
    
    child.on('close', (code) => {
      if (code !== 0) {
        reject(new Error(`Command failed: ${command}`));
      } else {
        resolve();
      }
    });
  });
}

module.exports = router;