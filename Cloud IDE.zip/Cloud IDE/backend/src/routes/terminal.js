// backend/src/routes/terminal.js
const express = require('express');
const { spawn } = require('child_process');
const path = require('path');

const router = express.Router();
const WORKSPACE_PATH = process.env.WORKSPACE_PATH || '/workspace';

/**
 * POST /api/terminal/execute
 * Execute a command in the terminal
 */
router.post('/execute', async (req, res) => {
  try {
    const { command, workingDirectory = '/' } = req.body;

    if (!command) {
      return res.status(400).json({ error: 'Command is required' });
    }

    // Sanitize working directory
    const safeCwd = path.join(WORKSPACE_PATH, workingDirectory);

    // Security: Block dangerous commands
    const blockedCommands = ['rm -rf /', 'sudo', 'su', 'passwd', 'shutdown', 'reboot'];
    const commandLower = command.toLowerCase();
    
    if (blockedCommands.some(blocked => commandLower.includes(blocked))) {
      return res.status(403).json({ error: 'Command not allowed' });
    }

    const child = spawn('sh', ['-c', command], {
      cwd: safeCwd,
      stdio: 'pipe',
      env: {
        ...process.env,
        PATH: process.env.PATH + ':/usr/local/bin:/usr/bin:/bin'
      }
    });

    let stdout = '';
    let stderr = '';

    child.stdout.on('data', (data) => {
      stdout += data.toString();
    });

    child.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    child.on('close', (code) => {
      res.json({
        success: true,
        data: {
          command,
          workingDirectory,
          exitCode: code,
          stdout,
          stderr,
          timestamp: new Date().toISOString()
        }
      });
    });

    // Timeout after 30 seconds
    setTimeout(() => {
      if (!child.killed) {
        child.kill('SIGTERM');
      }
    }, 30000);

  } catch (error) {
    console.error('Error executing command:', error);
    res.status(500).json({
      error: 'Failed to execute command',
      details: error.message
    });
  }
});

/**
 * GET /api/terminal/history
 * Get command history (placeholder for future implementation)
 */
router.get('/history', (req, res) => {
  res.json({
    success: true,
    data: {
      history: [],
      message: 'Command history feature coming soon'
    }
  });
});

/**
 * GET /api/terminal/env
 * Get environment variables
 */
router.get('/env', (req, res) => {
  // Filter sensitive environment variables
  const safeEnvVars = {};
  const sensitiveKeys = ['password', 'secret', 'key', 'token', 'private'];
  
  for (const [key, value] of Object.entries(process.env)) {
    const keyLower = key.toLowerCase();
    const isSensitive = sensitiveKeys.some(sensitive => keyLower.includes(sensitive));
    
    if (!isSensitive) {
      safeEnvVars[key] = value;
    }
  }

  res.json({
    success: true,
    data: {
      environment: safeEnvVars,
      workspacePath: WORKSPACE_PATH
    }
  });
});

module.exports = router;