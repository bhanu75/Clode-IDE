// backend/src/middleware/errorHandler.js
const errorHandler = (err, req, res, next) => {
  console.error('Error occurred:', {
    message: err.message,
    stack: err.stack,
    url: req.url,
    method: req.method,
    timestamp: new Date().toISOString()
  });

  // Default error
  let error = {
    success: false,
    error: 'Internal Server Error',
    details: err.message
  };

  // Mongoose bad ObjectId
  if (err.name === 'CastError') {
    error.error = 'Invalid ID format';
    error.statusCode = 400;
  }

  // Mongoose duplicate key
  if (err.code === 11000) {
    error.error = 'Duplicate field value entered';
    error.statusCode = 400;
  }

  // Mongoose validation error
  if (err.name === 'ValidationError') {
    const messages = Object.values(err.errors).map(val => val.message);
    error.error = 'Validation Error';
    error.details = messages.join(', ');
    error.statusCode = 400;
  }

  // File system errors
  if (err.code === 'ENOENT') {
    error.error = 'File or directory not found';
    error.statusCode = 404;
  }

  if (err.code === 'EACCES') {
    error.error = 'Permission denied';
    error.statusCode = 403;
  }

  if (err.code === 'EEXIST') {
    error.error = 'File or directory already exists';
    error.statusCode = 409;
  }

  // JWT errors
  if (err.name === 'JsonWebTokenError') {
    error.error = 'Invalid token';
    error.statusCode = 401;
  }

  if (err.name === 'TokenExpiredError') {
    error.error = 'Token expired';
    error.statusCode = 401;
  }

  // Multer errors (file upload)
  if (err.code === 'LIMIT_FILE_SIZE') {
    error.error = 'File too large';
    error.statusCode = 413;
  }

  if (err.code === 'LIMIT_UNEXPECTED_FILE') {
    error.error = 'Unexpected file field';
    error.statusCode = 400;
  }

  // Rate limiting errors
  if (err.status === 429) {
    error.error = 'Too many requests';
    error.details = 'Please try again later';
    error.statusCode = 429;
  }

  res.status(error.statusCode || 500).json(error);
};

module.exports = errorHandler;