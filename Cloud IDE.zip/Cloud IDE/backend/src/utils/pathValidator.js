// backend/src/utils/pathValidator.js
const path = require('path');

/**
 * Validate that a path is within the allowed workspace
 */
function validatePath(targetPath, workspacePath) {
  try {
    const resolved = path.resolve(targetPath);
    const workspaceResolved = path.resolve(workspacePath);
    
    // Check if the target path is within the workspace
    return resolved.startsWith(workspaceResolved);
  } catch (error) {
    return false;
  }
}

/**
 * Sanitize path to prevent directory traversal
 */
function sanitizePath(inputPath) {
  if (!inputPath || typeof inputPath !== 'string') {
    return '/';
  }

  // Remove any null bytes
  let cleanPath = inputPath.replace(/\0/g, '');
  
  // Normalize path separators
  cleanPath = cleanPath.replace(/\\/g, '/');
  
  // Remove dangerous patterns
  cleanPath = cleanPath.replace(/\.\.+/g, ''); // Remove .. and ...
  cleanPath = cleanPath.replace(/\/+/g, '/'); // Remove multiple slashes
  
  // Ensure path starts with /
  if (!cleanPath.startsWith('/')) {
    cleanPath = '/' + cleanPath;
  }
  
  // Remove trailing slash unless it's root
  if (cleanPath.length > 1 && cleanPath.endsWith('/')) {
    cleanPath = cleanPath.slice(0, -1);
  }

  return cleanPath;
}

/**
 * Check if filename is valid
 */
function isValidFilename(filename) {
  if (!filename || typeof filename !== 'string') {
    return false;
  }

  // Invalid characters for most file systems
  const invalidChars = /[<>:"|?*\x00-\x1f]/;
  
  // Reserved names on Windows
  const reservedNames = /^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$/i;
  
  // Check length (most file systems support 255 chars)
  if (filename.length > 255) {
    return false;
  }
  
  // Check for invalid characters
  if (invalidChars.test(filename)) {
    return false;
  }
  
  // Check for reserved names
  if (reservedNames.test(filename)) {
    return false;
  }
  
  // Cannot start or end with space or dot
  if (filename.startsWith(' ') || filename.endsWith(' ') || 
      filename.startsWith('.') || filename.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * Get file extension and validate if it's allowed
 */
function getAllowedExtensions() {
  return [
    // Web development
    '.html', '.htm', '.css', '.scss', '.sass', '.less',
    '.js', '.jsx', '.ts', '.tsx', '.vue', '.svelte',
    
    // Backend
    '.json', '.xml', '.yaml', '.yml', '.toml',
    '.py', '.java', '.cpp', '.c', '.h', '.hpp',
    '.php', '.rb', '.go', '.rs', '.swift', '.kt',
    
    // Documentation
    '.md', '.txt', '.rst', '.adoc',
    
    // Configuration
    '.env', '.config', '.conf', '.ini', '.properties',
    '.gitignore', '.dockerignore', '.editorconfig',
    
    // Data
    '.csv', '.tsv', '.sql'
  ];
}

/**
 * Check if file extension is allowed
 */
function isAllowedExtension(filename) {
  const ext = path.extname(filename).toLowerCase();
  const allowedExtensions = getAllowedExtensions();
  
  // Allow files without extension (like README, Dockerfile)
  if (!ext) {
    return true;
  }
  
  return allowedExtensions.includes(ext);
}

/**
 * Create safe file path within workspace
 */
function createSafePath(workspacePath, ...pathSegments) {
  const joinedPath = path.join(...pathSegments);
  const sanitized = sanitizePath(joinedPath);
  const fullPath = path.join(workspacePath, sanitized);
  
  if (!validatePath(fullPath, workspacePath)) {
    throw new Error('Invalid path: outside workspace');
  }
  
  return fullPath;
}

module.exports = {
  validatePath,
  sanitizePath,
  isValidFilename,
  getAllowedExtensions,
  isAllowedExtension,
  createSafePath
};