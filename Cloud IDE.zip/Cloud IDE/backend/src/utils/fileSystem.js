// backend/src/utils/fileSystem.js
const fs = require('fs').promises;
const path = require('path');

class FileSystem {
  /**
   * Get directory tree structure
   */
  static async getDirectoryTree(dirPath, maxDepth = 10, currentDepth = 0) {
    try {
      if (currentDepth >= maxDepth) {
        return { type: 'directory', name: path.basename(dirPath), children: [] };
      }

      const stats = await fs.stat(dirPath);
      
      if (stats.isFile()) {
        return {
          type: 'file',
          name: path.basename(dirPath),
          size: stats.size,
          modified: stats.mtime,
          extension: path.extname(dirPath)
        };
      }

      if (stats.isDirectory()) {
        const items = await fs.readdir(dirPath);
        const children = [];

        for (const item of items) {
          // Skip hidden files and node_modules in development
          if (item.startsWith('.') && item !== '.env') continue;
          if (item === 'node_modules') continue;
          
          const itemPath = path.join(dirPath, item);
          try {
            const child = await this.getDirectoryTree(itemPath, maxDepth, currentDepth + 1);
            children.push(child);
          } catch (error) {
            // Skip files that can't be read
            console.warn(`Skipping ${itemPath}: ${error.message}`);
          }
        }

        // Sort children: directories first, then files
        children.sort((a, b) => {
          if (a.type === 'directory' && b.type === 'file') return -1;
          if (a.type === 'file' && b.type === 'directory') return 1;
          return a.name.localeCompare(b.name);
        });

        return {
          type: 'directory',
          name: path.basename(dirPath),
          children,
          modified: stats.mtime
        };
      }
    } catch (error) {
      throw new Error(`Failed to read directory: ${error.message}`);
    }
  }

  /**
   * Read file content with encoding detection
   */
  static async readFile(filePath) {
    try {
      const stats = await fs.stat(filePath);
      
      // Check if file is too large (> 10MB)
      if (stats.size > 10 * 1024 * 1024) {
        throw new Error('File too large to read');
      }

      // Check if file is binary
      if (this.isBinaryFile(filePath)) {
        return {
          type: 'binary',
          message: 'Binary file - cannot display content',
          size: stats.size
        };
      }

      const content = await fs.readFile(filePath, 'utf8');
      return content;
    } catch (error) {
      if (error.code === 'ENOENT') {
        throw new Error('File not found');
      }
      throw new Error(`Failed to read file: ${error.message}`);
    }
  }

  /**
   * Check if file is binary
   */
  static isBinaryFile(filePath) {
    const binaryExtensions = [
      '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg',
      '.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm',
      '.mp3', '.wav', '.flac', '.aac', '.ogg',
      '.zip', '.rar', '.7z', '.tar', '.gz',
      '.exe', '.dll', '.so', '.dylib',
      '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
      '.sqlite', '.db'
    ];

    const ext = path.extname(filePath).toLowerCase();
    return binaryExtensions.includes(ext);
  }

  /**
   * Delete file or directory recursively
   */
  static async deleteFileOrDirectory(targetPath) {
    try {
      const stats = await fs.stat(targetPath);
      
      if (stats.isFile()) {
        await fs.unlink(targetPath);
      } else if (stats.isDirectory()) {
        await fs.rmdir(targetPath, { recursive: true });
      }
    } catch (error) {
      if (error.code === 'ENOENT') {
        throw new Error('File or directory not found');
      }
      throw new Error(`Failed to delete: ${error.message}`);
    }
  }

  /**
   * Search files by name or content
   */
  static async searchFiles(searchPath, query, searchType = 'name') {
    const results = [];
    
    try {
      await this._searchRecursive(searchPath, query, searchType, results);
      return results;
    } catch (error) {
      throw new Error(`Search failed: ${error.message}`);
    }
  }

  /**
   * Recursive search helper
   */
  static async _searchRecursive(dirPath, query, searchType, results, depth = 0) {
    if (depth > 20) return; // Prevent infinite recursion

    try {
      const items = await fs.readdir(dirPath);

      for (const item of items) {
        if (item.startsWith('.') || item === 'node_modules') continue;

        const itemPath = path.join(dirPath, item);
        const stats = await fs.stat(itemPath);

        if (stats.isDirectory()) {
          // Search directory name
          if (searchType === 'name' && item.toLowerCase().includes(query.toLowerCase())) {
            results.push({
              type: 'directory',
              name: item,
              path: itemPath,
              relativePath: path.relative(process.env.WORKSPACE_PATH || '/workspace', itemPath)
            });
          }
          
          // Recurse into directory
          await this._searchRecursive(itemPath, query, searchType, results, depth + 1);
        } else if (stats.isFile()) {
          let match = false;

          // Search by filename
          if (searchType === 'name' && item.toLowerCase().includes(query.toLowerCase())) {
            match = true;
          }

          // Search by file content
          if (searchType === 'content' && !this.isBinaryFile(itemPath) && stats.size < 1024 * 1024) {
            try {
              const content = await fs.readFile(itemPath, 'utf8');
              if (content.toLowerCase().includes(query.toLowerCase())) {
                match = true;
              }
            } catch (error) {
              // Skip files that can't be read
            }
          }

          if (match) {
            results.push({
              type: 'file',
              name: item,
              path: itemPath,
              relativePath: path.relative(process.env.WORKSPACE_PATH || '/workspace', itemPath),
              size: stats.size,
              modified: stats.mtime,
              extension: path.extname(item)
            });
          }
        }
      }
    } catch (error) {
      // Skip directories that can't be read
      console.warn(`Skipping directory ${dirPath}: ${error.message}`);
    }
  }

  /**
   * Get file statistics
   */
  static async getFileStats(filePath) {
    try {
      const stats = await fs.stat(filePath);
      return {
        size: stats.size,
        created: stats.birthtime,
        modified: stats.mtime,
        accessed: stats.atime,
        isFile: stats.isFile(),
        isDirectory: stats.isDirectory(),
        permissions: stats.mode
      };
    } catch (error) {
      throw new Error(`Failed to get file stats: ${error.message}`);
    }
  }

  /**
   * Copy file or directory
   */
  static async copy(sourcePath, destPath) {
    try {
      const stats = await fs.stat(sourcePath);
      
      if (stats.isFile()) {
        await fs.copyFile(sourcePath, destPath);
      } else if (stats.isDirectory()) {
        await this._copyDirectory(sourcePath, destPath);
      }
    } catch (error) {
      throw new Error(`Failed to copy: ${error.message}`);
    }
  }

  /**
   * Copy directory recursively
   */
  static async _copyDirectory(sourceDir, destDir) {
    await fs.mkdir(destDir, { recursive: true });
    const items = await fs.readdir(sourceDir);

    for (const item of items) {
      const sourcePath = path.join(sourceDir, item);
      const destPath = path.join(destDir, item);
      
      await this.copy(sourcePath, destPath);
    }
  }
}

module.exports = FileSystem;