// backend/src/websocket/handler.js
const chokidar = require('chokidar');
const path = require('path');
const pty = require('node-pty');
const os = require('os');

class WebSocketHandler {
  constructor(io) {
    this.io = io;
    this.terminals = new Map(); // Store terminal sessions
    this.fileWatchers = new Map(); // Store file watchers
    this.workspacePath = process.env.WORKSPACE_PATH || '/workspace';
    
    this.setupConnectionHandling();
  }

  setupConnectionHandling() {
    this.io.on('connection', (socket) => {
      console.log(`🔌 Client connected: ${socket.id}`);
      
      // Send welcome message
      socket.emit('connected', {
        message: 'Connected to Cloud IDE',
        socketId: socket.id,
        timestamp: new Date().toISOString()
      });

      // Set up event handlers
      this.setupFileWatching(socket);
      this.setupTerminalHandling(socket);
      this.setupCollaboration(socket);
      
      // Handle disconnection
      socket.on('disconnect', () => {
        this.handleDisconnect(socket);
      });
    });
  }

  /**
   * File watching and real-time updates
   */
  setupFileWatching(socket) {
    // Start file watching
    socket.on('watch-files', (data) => {
      const { path: watchPath = '/' } = data;
      const fullPath = path.join(this.workspacePath, watchPath);
      
      try {
        // Stop existing watcher for this socket
        if (this.fileWatchers.has(socket.id)) {
          this.fileWatchers.get(socket.id).close();
        }

        // Create new watcher
        const watcher = chokidar.watch(fullPath, {
          ignored: /(^|[\/\\])\../,
          persistent: true,
          ignoreInitial: true
        });

        // File change events
        watcher
          .on('add', (filePath) => {
            socket.emit('file-added', {
              path: path.relative(this.workspacePath, filePath),
              timestamp: new Date().toISOString()
            });
          })
          .on('change', (filePath) => {
            socket.emit('file-changed', {
              path: path.relative(this.workspacePath, filePath),
              timestamp: new Date().toISOString()
            });
          })
          .on('unlink', (filePath) => {
            socket.emit('file-deleted', {
              path: path.relative(this.workspacePath, filePath),
              timestamp: new Date().toISOString()
            });
          })
          .on('addDir', (dirPath) => {
            socket.emit('directory-added', {
              path: path.relative(this.workspacePath, dirPath),
              timestamp: new Date().toISOString()
            });
          })
          .on('unlinkDir', (dirPath) => {
            socket.emit('directory-deleted', {
              path: path.relative(this.workspacePath, dirPath),
              timestamp: new Date().toISOString()
            });
          });

        this.fileWatchers.set(socket.id, watcher);
        
        socket.emit('file-watch-started', {
          path: watchPath,
          message: 'File watching started'
        });
      } catch (error) {
        socket.emit('error', {
          type: 'file-watch-error',
          message: error.message
        });
      }
    });

    // Stop file watching
    socket.on('stop-watch-files', () => {
      if (this.fileWatchers.has(socket.id)) {
        this.fileWatchers.get(socket.id).close();
        this.fileWatchers.delete(socket.id);
        
        socket.emit('file-watch-stopped', {
          message: 'File watching stopped'
        });
      }
    });
  }

  /**
   * Terminal handling
   */
  setupTerminalHandling(socket) {
    // Create new terminal
    socket.on('create-terminal', (data) => {
      try {
        const { id = 'default', shell = process.env.TERMINAL_SHELL || '/bin/bash' } = data;
        
        // Create terminal process
        const terminal = pty.spawn(shell, [], {
          name: 'xterm-color',
          cols: parseInt(process.env.TERMINAL_COLS) || 80,
          rows: parseInt(process.env.TERMINAL_ROWS) || 24,
          cwd: this.workspacePath,
          env: {
            ...process.env,
            TERM: 'xterm-256color',
            COLORTERM: 'truecolor'
          }
        });

        // Store terminal session
        const terminalKey = `${socket.id}-${id}`;
        this.terminals.set(terminalKey, {
          terminal,
          id,
          created: new Date(),
          lastActivity: new Date()
        });

        // Handle terminal output
        terminal.on('data', (data) => {
          socket.emit('terminal-output', {
            id,
            data: data.toString()
          });
          
          // Update last activity
          const terminalSession = this.terminals.get(terminalKey);
          if (terminalSession) {
            terminalSession.lastActivity = new Date();
          }
        });

        // Handle terminal exit
        terminal.on('exit', (code) => {
          socket.emit('terminal-exit', {
            id,
            code,
            message: `Terminal exited with code ${code}`
          });
          
          this.terminals.delete(terminalKey);
        });

        socket.emit('terminal-created', {
          id,
          message: 'Terminal created successfully',
          pid: terminal.pid
        });
      } catch (error) {
        socket.emit('error', {
          type: 'terminal-creation-error',
          message: error.message
        });
      }
    });

    // Send input to terminal
    socket.on('terminal-input', (data) => {
      const { id = 'default', input } = data;
      const terminalKey = `${socket.id}-${id}`;
      
      const terminalSession = this.terminals.get(terminalKey);
      if (terminalSession) {
        terminalSession.terminal.write(input);
        terminalSession.lastActivity = new Date();
      } else {
        socket.emit('error', {
          type: 'terminal-not-found',
          message: `Terminal ${id} not found`
        });
      }
    });

    // Resize terminal
    socket.on('terminal-resize', (data) => {
      const { id = 'default', cols, rows } = data;
      const terminalKey = `${socket.id}-${id}`;
      
      const terminalSession = this.terminals.get(terminalKey);
      if (terminalSession) {
        terminalSession.terminal.resize(cols, rows);
        
        socket.emit('terminal-resized', {
          id,
          cols,
          rows
        });
      }
    });

    // Kill terminal
    socket.on('kill-terminal', (data) => {
      const { id = 'default' } = data;
      const terminalKey = `${socket.id}-${id}`;
      
      const terminalSession = this.terminals.get(terminalKey);
      if (terminalSession) {
        terminalSession.terminal.kill();
        this.terminals.delete(terminalKey);
        
        socket.emit('terminal-killed', {
          id,
          message: 'Terminal killed'
        });
      }
    });
  }

  /**
   * Real-time collaboration features
   */
  setupCollaboration(socket) {
    // Join a project room for collaboration
    socket.on('join-project', (data) => {
      const { projectId } = data;
      socket.join(`project-${projectId}`);
      
      socket.emit('project-joined', {
        projectId,
        message: 'Joined project room'
      });
      
      // Notify other users in the project
      socket.to(`project-${projectId}`).emit('user-joined', {
        socketId: socket.id,
        timestamp: new Date().toISOString()
      });
    });

    // Leave project room
    socket.on('leave-project', (data) => {
      const { projectId } = data;
      socket.leave(`project-${projectId}`);
      
      // Notify other users
      socket.to(`project-${projectId}`).emit('user-left', {
        socketId: socket.id,
        timestamp: new Date().toISOString()
      });
    });

    // Share cursor position
    socket.on('cursor-position', (data) => {
      const { projectId, filePath, line, column } = data;
      
      socket.to(`project-${projectId}`).emit('cursor-update', {
        socketId: socket.id,
        filePath,
        line,
        column,
        timestamp: new Date().toISOString()
      });
    });

    // Share file changes in real-time
    socket.on('file-edit', (data) => {
      const { projectId, filePath, changes, version } = data;
      
      socket.to(`project-${projectId}`).emit('file-changes', {
        socketId: socket.id,
        filePath,
        changes,
        version,
        timestamp: new Date().toISOString()
      });
    });

    // Chat messages
    socket.on('chat-message', (data) => {
      const { projectId, message, username } = data;
      
      this.io.to(`project-${projectId}`).emit('chat-message', {
        socketId: socket.id,
        username: username || 'Anonymous',
        message,
        timestamp: new Date().toISOString()
      });
    });
  }

  /**
   * Handle client disconnection
   */
  handleDisconnect(socket) {
    console.log(`🔌 Client disconnected: ${socket.id}`);
    
    // Clean up terminals
    const terminalKeys = Array.from(this.terminals.keys()).filter(key => 
      key.startsWith(socket.id)
    );
    
    terminalKeys.forEach(key => {
      const terminalSession = this.terminals.get(key);
      if (terminalSession) {
        terminalSession.terminal.kill();
        this.terminals.delete(key);
      }
    });

    // Clean up file watchers
    if (this.fileWatchers.has(socket.id)) {
      this.fileWatchers.get(socket.id).close();
      this.fileWatchers.delete(socket.id);
    }

    // Notify project rooms about user leaving
    const rooms = Array.from(socket.rooms).filter(room => 
      room.startsWith('project-')
    );
    
    rooms.forEach(room => {
      socket.to(room).emit('user-disconnected', {
        socketId: socket.id,
        timestamp: new Date().toISOString()
      });
    });
  }

  /**
   * Cleanup inactive terminals
   */
  cleanupInactiveTerminals() {
    const now = new Date();
    const timeout = parseInt(process.env.TERMINAL_TIMEOUT) || 300000; // 5 minutes
    
    for (const [key, session] of this.terminals.entries()) {
      if (now - session.lastActivity > timeout) {
        console.log(`🧹 Cleaning up inactive terminal: ${key}`);
        session.terminal.kill();
        this.terminals.delete(key);
      }
    }
  }

  /**
   * Get statistics
   */
  getStats() {
    return {
      connectedClients: this.io.sockets.sockets.size,
      activeTerminals: this.terminals.size,
      fileWatchers: this.fileWatchers.size,
      uptime: process.uptime()
    };
  }
}

// Cleanup function to run periodically
setInterval(() => {
  // This will be called by the main handler instance
}, 60000); // Run every minute

module.exports = (io) => {
  const handler = new WebSocketHandler(io);
  
  // Set up periodic cleanup
  setInterval(() => {
    handler.cleanupInactiveTerminals();
  }, 60000);
  
  return handler;
};