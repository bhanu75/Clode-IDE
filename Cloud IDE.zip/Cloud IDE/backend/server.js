// backend/server.js
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

// Import routes
const fileRoutes = require('./src/routes/files');
const projectRoutes = require('./src/routes/projects');
const terminalRoutes = require('./src/routes/terminal');

// Import WebSocket handler
const websocketHandler = require('./src/websocket/handler');

// Import middleware
const errorHandler = require('./src/middleware/errorHandler');
const authMiddleware = require('./src/middleware/auth');

class CloudIDEServer {
  constructor() {
    this.app = express();
    this.server = http.createServer(this.app);
    this.io = socketIo(this.server, {
      cors: {
        origin: process.env.CORS_ORIGIN || "http://localhost:3000",
        methods: ["GET", "POST"],
        credentials: true
      }
    });
    
    this.port = process.env.PORT || 3001;
    this.setupMiddleware();
    this.setupRoutes();
    this.setupWebSocket();
    this.setupErrorHandling();
  }

  setupMiddleware() {
    // Security middleware
    this.app.use(helmet({
      contentSecurityPolicy: false, // Disable CSP for development
      crossOriginEmbedderPolicy: false
    }));

    // Rate limiting
    const limiter = rateLimit({
      windowMs: 15 * 60 * 1000, // 15 minutes
      max: 1000, // Limit each IP to 1000 requests per windowMs
      message: 'Too many requests from this IP'
    });
    this.app.use(limiter);

    // CORS configuration
    this.app.use(cors({
      origin: process.env.CORS_ORIGIN || "http://localhost:3000",
      credentials: true,
      methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
      allowedHeaders: ['Content-Type', 'Authorization']
    }));

    // Body parsing middleware
    this.app.use(express.json({ limit: '50mb' }));
    this.app.use(express.urlencoded({ extended: true, limit: '50mb' }));

    // Compression
    this.app.use(compression());

    // Logging
    if (process.env.NODE_ENV !== 'test') {
      this.app.use(morgan('combined'));
    }

    // Static files (for serving frontend in production)
    if (process.env.NODE_ENV === 'production') {
      this.app.use(express.static('public'));
    }
  }

  setupRoutes() {
    // Health check endpoint
    this.app.get('/health', (req, res) => {
      res.status(200).json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        version: process.env.APP_VERSION || '1.0.0'
      });
    });

    // API routes
    this.app.use('/api/files', fileRoutes);
    this.app.use('/api/projects', projectRoutes);
    this.app.use('/api/terminal', terminalRoutes);

    // Root endpoint
    this.app.get('/', (req, res) => {
      res.json({
        message: 'Cloud IDE Backend API',
        version: '1.0.0',
        endpoints: {
          health: '/health',
          files: '/api/files',
          projects: '/api/projects',
          terminal: '/api/terminal',
          websocket: '/socket.io'
        }
      });
    });

    // 404 handler
    this.app.use('*', (req, res) => {
      res.status(404).json({
        error: 'Endpoint not found',
        path: req.originalUrl,
        method: req.method
      });
    });
  }

  setupWebSocket() {
    // Initialize WebSocket handlers
    websocketHandler(this.io);
    
    console.log('🔌 WebSocket server initialized');
  }

  setupErrorHandling() {
    // Global error handler
    this.app.use(errorHandler);

    // Graceful shutdown
    process.on('SIGTERM', this.shutdown.bind(this));
    process.on('SIGINT', this.shutdown.bind(this));
  }

  start() {
    this.server.listen(this.port, () => {
      console.log(`🚀 Cloud IDE Backend running on port ${this.port}`);
      console.log(`📁 Environment: ${process.env.NODE_ENV || 'development'}`);
      console.log(`🌐 CORS Origin: ${process.env.CORS_ORIGIN || 'http://localhost:3000'}`);
      console.log(`🔗 WebSocket enabled on /socket.io`);
    });
  }

  shutdown() {
    console.log('🛑 Shutting down server gracefully...');
    
    this.server.close(() => {
      console.log('✅ Server shut down complete');
      process.exit(0);
    });

    // Force close after 10 seconds
    setTimeout(() => {
      console.log('⚠️ Forcing server shutdown');
      process.exit(1);
    }, 10000);
  }
}

// Create and start server
const server = new CloudIDEServer();
server.start();

module.exports = server;